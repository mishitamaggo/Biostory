# BioStory AI - Architecture Plan

## Overview
BioStory AI transforms complex biotech research into investor-ready stories through automated AI-powered conversion tools. The app serves biotech founders, scientists, and accelerators who need to communicate technical concepts in clear, compelling formats.

## MVP Features
1. **Document Upload & Analysis** - Upload research papers, pitch decks, or grant applications
2. **AI Story Generation** - Convert technical content into clear, visual storytelling 
3. **One-Line Explanations** - Generate plain English summaries of biotech concepts
4. **Template Gallery** - Browse and select from branded pitch templates
5. **Story Editor** - Edit and customize generated stories with rich formatting
6. **Export & Share** - Download finished presentations and share links
7. **Project Management** - Save, organize, and manage multiple biotech stories
8. **Usage Analytics** - Track generations and subscription usage

## Technical Architecture

### Data Models (`lib/models/`)
1. **User** - User profiles, subscription plans, usage tracking
2. **Project** - Individual biotech story projects with metadata
3. **Story** - Generated stories with sections, content, and formatting
4. **Template** - Reusable presentation templates with styling
5. **Generation** - AI generation history and results
6. **Analytics** - Usage tracking and metrics

### Services (`lib/services/`)
1. **UserService** - User management and authentication
2. **ProjectService** - Project CRUD operations and local storage
3. **StoryService** - Story generation, editing, and management
4. **TemplateService** - Template management and customization
5. **GenerationService** - AI integration and content processing
6. **AnalyticsService** - Usage tracking and reporting
7. **OpenAIService** - AI model integration for content generation

### Screens (`lib/screens/`)
1. **HomeScreen** - Dashboard with recent projects and quick actions
2. **ProjectListScreen** - View and manage all biotech story projects
3. **CreateProjectScreen** - Upload documents and start new projects
4. **StoryEditorScreen** - Edit and customize generated stories
5. **TemplateGalleryScreen** - Browse and select presentation templates
6. **ExportScreen** - Download and share finished presentations
7. **AnalyticsScreen** - View usage statistics and subscription status
8. **SettingsScreen** - App preferences and account management

### Widgets (`lib/widgets/`)
- **ProjectCard** - Display project information in grid/list
- **StorySection** - Editable story content blocks
- **TemplateCard** - Template preview and selection
- **GenerationProgress** - AI processing status indicator
- **DocumentUpload** - File upload with drag-and-drop
- **ExportOptions** - Format selection and download controls

### Color Scheme
Modern biotech-inspired palette:
- **Primary**: Deep teal (#006B7D) - Professional, scientific
- **Secondary**: Vibrant cyan (#00BCD4) - Innovation, technology  
- **Accent**: Coral (#FF6B6B) - Energy, creativity
- **Success**: Emerald green (#10B981) - Growth, progress
- **Background**: Clean whites and soft grays
- **Text**: Charcoal gray (#374151) with high contrast

### Key Features
- **Local Storage**: All data persists locally using SharedPreferences
- **AI Integration**: OpenAI GPT-4o for content generation and analysis
- **File Upload**: Support for PDF, DOCX, and PPT document upload
- **Rich Text Editor**: Format and customize generated content
- **Template System**: Pre-designed layouts for different biotech sectors
- **Export Formats**: PDF presentation and shareable web links

## Implementation Priority
1. Set up core data models and services
2. Create home screen and project management
3. Implement document upload and AI integration
4. Build story editor with rich formatting
5. Add template gallery and customization
6. Create export and sharing functionality
7. Add analytics and usage tracking
8. Polish UI/UX and add animations
9. Test and debug the complete flow
10. Compile and validate the final application
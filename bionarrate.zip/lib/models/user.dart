import 'package:uuid/uuid.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class User {
  final String id;
  final String name;
  final String email;
  final String subscriptionPlan;
  final int generationsUsed;
  final int generationsLimit;
  final DateTime createdAt;
  final DateTime updatedAt;

  const User({
    required this.id,
    required this.name,
    required this.email,
    this.subscriptionPlan = 'free',
    this.generationsUsed = 0,
    this.generationsLimit = 3,
    required this.createdAt,
    required this.updatedAt,
  });

  factory User.create({
    required String name,
    required String email,
    String subscriptionPlan = 'free',
  }) {
    final now = DateTime.now();
    return User(
      id: const Uuid().v4(),
      name: name,
      email: email,
      subscriptionPlan: subscriptionPlan,
      createdAt: now,
      updatedAt: now,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'email': email,
        'subscriptionPlan': subscriptionPlan,
        'generationsUsed': generationsUsed,
        'generationsLimit': generationsLimit,
        'createdAt': Timestamp.fromDate(createdAt),
        'updatedAt': Timestamp.fromDate(updatedAt),
      };

  factory User.fromJson(Map<String, dynamic> json) => User(
        id: json['id'] as String,
        name: json['name'] as String,
        email: json['email'] as String,
        subscriptionPlan: json['subscriptionPlan'] as String? ?? 'free',
        generationsUsed: json['generationsUsed'] as int? ?? 0,
        generationsLimit: json['generationsLimit'] as int? ?? 3,
        createdAt: _parseDateTime(json['createdAt']),
        updatedAt: _parseDateTime(json['updatedAt']),
      );

  static DateTime _parseDateTime(dynamic value) {
    if (value is Timestamp) {
      return value.toDate();
    } else if (value is String) {
      return DateTime.parse(value);
    }
    return DateTime.now();
  }

  User copyWith({
    String? name,
    String? email,
    String? subscriptionPlan,
    int? generationsUsed,
    int? generationsLimit,
  }) =>
      User(
        id: id,
        name: name ?? this.name,
        email: email ?? this.email,
        subscriptionPlan: subscriptionPlan ?? this.subscriptionPlan,
        generationsUsed: generationsUsed ?? this.generationsUsed,
        generationsLimit: generationsLimit ?? this.generationsLimit,
        createdAt: createdAt,
        updatedAt: DateTime.now(),
      );

  bool get hasGenerationsLeft => generationsUsed < generationsLimit;
  
  bool get isPremium => subscriptionPlan != 'free';
}
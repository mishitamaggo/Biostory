import 'package:uuid/uuid.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

enum TemplateCategory { pitch, grant, investor, website, general }

class Template {
  final String id;
  final String name;
  final String description;
  final TemplateCategory category;
  final String thumbnailUrl;
  final List<String> sectionTitles;
  final Map<String, String> styling;
  final bool isPremium;
  final DateTime createdAt;
  final DateTime updatedAt;

  const Template({
    required this.id,
    required this.name,
    required this.description,
    required this.category,
    required this.thumbnailUrl,
    required this.sectionTitles,
    this.styling = const {},
    this.isPremium = false,
    required this.createdAt,
    required this.updatedAt,
  });

  factory Template.create({
    required String name,
    required String description,
    required TemplateCategory category,
    required String thumbnailUrl,
    required List<String> sectionTitles,
    Map<String, String>? styling,
    bool isPremium = false,
  }) {
    final now = DateTime.now();
    return Template(
      id: const Uuid().v4(),
      name: name,
      description: description,
      category: category,
      thumbnailUrl: thumbnailUrl,
      sectionTitles: sectionTitles,
      styling: styling ?? {},
      isPremium: isPremium,
      createdAt: now,
      updatedAt: now,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'description': description,
        'category': category.name,
        'thumbnailUrl': thumbnailUrl,
        'sectionTitles': sectionTitles,
        'styling': styling,
        'isPremium': isPremium,
        'createdAt': Timestamp.fromDate(createdAt),
        'updatedAt': Timestamp.fromDate(updatedAt),
      };

  factory Template.fromJson(Map<String, dynamic> json) => Template(
        id: json['id'] as String,
        name: json['name'] as String,
        description: json['description'] as String,
        category: TemplateCategory.values.firstWhere(
          (e) => e.name == (json['category'] as String),
          orElse: () => TemplateCategory.general,
        ),
        thumbnailUrl: json['thumbnailUrl'] as String,
        sectionTitles: List<String>.from(json['sectionTitles'] as List),
        styling: Map<String, String>.from(json['styling'] as Map? ?? {}),
        isPremium: json['isPremium'] as bool? ?? false,
        createdAt: _parseDateTime(json['createdAt']),
        updatedAt: _parseDateTime(json['updatedAt']),
      );

  Template copyWith({
    String? name,
    String? description,
    TemplateCategory? category,
    String? thumbnailUrl,
    List<String>? sectionTitles,
    Map<String, String>? styling,
    bool? isPremium,
  }) =>
      Template(
        id: id,
        name: name ?? this.name,
        description: description ?? this.description,
        category: category ?? this.category,
        thumbnailUrl: thumbnailUrl ?? this.thumbnailUrl,
        sectionTitles: sectionTitles ?? this.sectionTitles,
        styling: styling ?? this.styling,
        isPremium: isPremium ?? this.isPremium,
        createdAt: createdAt,
        updatedAt: DateTime.now(),
      );

  static DateTime _parseDateTime(dynamic value) {
    if (value is Timestamp) {
      return value.toDate();
    } else if (value is String) {
      return DateTime.parse(value);
    }
    return DateTime.now();
  }

  String get categoryDisplayText {
    switch (category) {
      case TemplateCategory.pitch:
        return 'Pitch Deck';
      case TemplateCategory.grant:
        return 'Grant Application';
      case TemplateCategory.investor:
        return 'Investor Presentation';
      case TemplateCategory.website:
        return 'Website Content';
      case TemplateCategory.general:
        return 'General';
    }
  }

  int get sectionCount => sectionTitles.length;
}
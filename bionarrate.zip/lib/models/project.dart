import 'package:uuid/uuid.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

enum ProjectStatus { draft, processing, completed, error }

enum DocumentType { pdf, docx, pptx, txt }

class Project {
  final String id;
  final String userId;
  final String title;
  final String description;
  final String? documentPath;
  final DocumentType? documentType;
  final ProjectStatus status;
  final String? templateId;
  final int storyCount;
  final DateTime createdAt;
  final DateTime updatedAt;

  const Project({
    required this.id,
    required this.userId,
    required this.title,
    required this.description,
    this.documentPath,
    this.documentType,
    this.status = ProjectStatus.draft,
    this.templateId,
    this.storyCount = 0,
    required this.createdAt,
    required this.updatedAt,
  });

  factory Project.create({
    required String userId,
    required String title,
    required String description,
  }) {
    final now = DateTime.now();
    return Project(
      id: const Uuid().v4(),
      userId: userId,
      title: title,
      description: description,
      createdAt: now,
      updatedAt: now,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'userId': userId,
        'title': title,
        'description': description,
        'documentPath': documentPath,
        'documentType': documentType?.name,
        'status': status.name,
        'templateId': templateId,
        'storyCount': storyCount,
        'createdAt': Timestamp.fromDate(createdAt),
        'updatedAt': Timestamp.fromDate(updatedAt),
      };

  factory Project.fromJson(Map<String, dynamic> json) => Project(
        id: json['id'] as String,
        userId: json['userId'] as String,
        title: json['title'] as String,
        description: json['description'] as String,
        documentPath: json['documentPath'] as String?,
        documentType: json['documentType'] != null
            ? DocumentType.values.firstWhere(
                (e) => e.name == json['documentType'],
                orElse: () => DocumentType.pdf,
              )
            : null,
        status: ProjectStatus.values.firstWhere(
          (e) => e.name == (json['status'] as String? ?? 'draft'),
          orElse: () => ProjectStatus.draft,
        ),
        templateId: json['templateId'] as String?,
        storyCount: json['storyCount'] as int? ?? 0,
        createdAt: _parseDateTime(json['createdAt']),
        updatedAt: _parseDateTime(json['updatedAt']),
      );

  Project copyWith({
    String? title,
    String? description,
    String? documentPath,
    DocumentType? documentType,
    ProjectStatus? status,
    String? templateId,
    int? storyCount,
  }) =>
      Project(
        id: id,
        userId: userId,
        title: title ?? this.title,
        description: description ?? this.description,
        documentPath: documentPath ?? this.documentPath,
        documentType: documentType ?? this.documentType,
        status: status ?? this.status,
        templateId: templateId ?? this.templateId,
        storyCount: storyCount ?? this.storyCount,
        createdAt: createdAt,
        updatedAt: DateTime.now(),
      );

  static DateTime _parseDateTime(dynamic value) {
    if (value is Timestamp) {
      return value.toDate();
    } else if (value is String) {
      return DateTime.parse(value);
    }
    return DateTime.now();
  }

  String get statusDisplayText {
    switch (status) {
      case ProjectStatus.draft:
        return 'Draft';
      case ProjectStatus.processing:
        return 'Processing';
      case ProjectStatus.completed:
        return 'Completed';
      case ProjectStatus.error:
        return 'Error';
    }
  }

  bool get isCompleted => status == ProjectStatus.completed;
  bool get isProcessing => status == ProjectStatus.processing;
  bool get hasDocument => documentPath != null;
}
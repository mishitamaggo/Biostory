import 'package:uuid/uuid.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class StorySection {
  final String id;
  final String title;
  final String content;
  final String? imageUrl;
  final int order;

  const StorySection({
    required this.id,
    required this.title,
    required this.content,
    this.imageUrl,
    required this.order,
  });

  factory StorySection.create({
    required String title,
    required String content,
    String? imageUrl,
    required int order,
  }) =>
      StorySection(
        id: const Uuid().v4(),
        title: title,
        content: content,
        imageUrl: imageUrl,
        order: order,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'content': content,
        'imageUrl': imageUrl,
        'order': order,
      };

  factory StorySection.fromJson(Map<String, dynamic> json) => StorySection(
        id: json['id'] as String,
        title: json['title'] as String,
        content: json['content'] as String,
        imageUrl: json['imageUrl'] as String?,
        order: json['order'] as int,
      );

  StorySection copyWith({
    String? title,
    String? content,
    String? imageUrl,
    int? order,
  }) =>
      StorySection(
        id: id,
        title: title ?? this.title,
        content: content ?? this.content,
        imageUrl: imageUrl ?? this.imageUrl,
        order: order ?? this.order,
      );
}

class Story {
  final String id;
  final String userId;
  final String projectId;
  final String title;
  final String oneLineExplanation;
  final List<StorySection> sections;
  final String? templateId;
  final DateTime createdAt;
  final DateTime updatedAt;

  const Story({
    required this.id,
    required this.userId,
    required this.projectId,
    required this.title,
    required this.oneLineExplanation,
    required this.sections,
    this.templateId,
    required this.createdAt,
    required this.updatedAt,
  });

  factory Story.create({
    required String userId,
    required String projectId,
    required String title,
    required String oneLineExplanation,
    List<StorySection>? sections,
    String? templateId,
  }) {
    final now = DateTime.now();
    return Story(
      id: const Uuid().v4(),
      userId: userId,
      projectId: projectId,
      title: title,
      oneLineExplanation: oneLineExplanation,
      sections: sections ?? [],
      templateId: templateId,
      createdAt: now,
      updatedAt: now,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'userId': userId,
        'projectId': projectId,
        'title': title,
        'oneLineExplanation': oneLineExplanation,
        'sections': sections.map((s) => s.toJson()).toList(),
        'templateId': templateId,
        'createdAt': Timestamp.fromDate(createdAt),
        'updatedAt': Timestamp.fromDate(updatedAt),
      };

  factory Story.fromJson(Map<String, dynamic> json) => Story(
        id: json['id'] as String,
        userId: json['userId'] as String,
        projectId: json['projectId'] as String,
        title: json['title'] as String,
        oneLineExplanation: json['oneLineExplanation'] as String,
        sections: (json['sections'] as List<dynamic>?)
                ?.map((s) => StorySection.fromJson(s as Map<String, dynamic>))
                .toList() ??
            [],
        templateId: json['templateId'] as String?,
        createdAt: _parseDateTime(json['createdAt']),
        updatedAt: _parseDateTime(json['updatedAt']),
      );

  Story copyWith({
    String? title,
    String? oneLineExplanation,
    List<StorySection>? sections,
    String? templateId,
  }) =>
      Story(
        id: id,
        userId: userId,
        projectId: projectId,
        title: title ?? this.title,
        oneLineExplanation: oneLineExplanation ?? this.oneLineExplanation,
        sections: sections ?? this.sections,
        templateId: templateId ?? this.templateId,
        createdAt: createdAt,
        updatedAt: DateTime.now(),
      );

  static DateTime _parseDateTime(dynamic value) {
    if (value is Timestamp) {
      return value.toDate();
    } else if (value is String) {
      return DateTime.parse(value);
    }
    return DateTime.now();
  }

  int get sectionCount => sections.length;
  
  String get summary => sections.isEmpty 
      ? 'No content yet' 
      : '${sections.length} sections';
}
import 'package:flutter/material.dart';
import 'package:bionarrate/models/template.dart';

class TemplateCard extends StatelessWidget {
  final Template template;
  final VoidCallback? onTap;

  const TemplateCard({
    super.key,
    required this.template,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildThumbnail(context),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildHeader(context),
                    const SizedBox(height: 8),
                    _buildTitle(context),
                    const SizedBox(height: 4),
                    _buildDescription(context),
                    const Spacer(),
                    _buildFooter(context),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildThumbnail(BuildContext context) {
    return Container(
      height: 120,
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.grey.shade100,
        image: template.thumbnailUrl.isNotEmpty
            ? DecorationImage(
                image: NetworkImage(template.thumbnailUrl),
                fit: BoxFit.cover,
              )
            : null,
      ),
      child: template.thumbnailUrl.isEmpty
          ? Center(
              child: Icon(
                Icons.dashboard_outlined,
                size: 48,
                color: Colors.grey.shade400,
              ),
            )
          : null,
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        _buildCategoryChip(context),
        if (template.isPremium) _buildPremiumBadge(context),
      ],
    );
  }

  Widget _buildCategoryChip(BuildContext context) {
    Color categoryColor;
    switch (template.category) {
      case TemplateCategory.pitch:
        categoryColor = Theme.of(context).colorScheme.primary;
        break;
      case TemplateCategory.grant:
        categoryColor = Theme.of(context).colorScheme.tertiary;
        break;
      case TemplateCategory.investor:
        categoryColor = Theme.of(context).colorScheme.error;
        break;
      case TemplateCategory.website:
        categoryColor = Colors.purple;
        break;
      default:
        categoryColor = Colors.grey;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: categoryColor.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        template.categoryDisplayText,
        style: TextStyle(
          fontSize: 10,
          fontWeight: FontWeight.w600,
          color: categoryColor,
        ),
      ),
    );
  }

  Widget _buildPremiumBadge(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: Colors.amber.shade100,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.star,
            size: 12,
            color: Colors.amber.shade700,
          ),
          const SizedBox(width: 2),
          Text(
            'PRO',
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.bold,
              color: Colors.amber.shade700,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTitle(BuildContext context) {
    return Text(
      template.name,
      style: Theme.of(context).textTheme.titleSmall?.copyWith(
            fontWeight: FontWeight.w600,
          ),
      maxLines: 2,
      overflow: TextOverflow.ellipsis,
    );
  }

  Widget _buildDescription(BuildContext context) {
    return Text(
      template.description,
      style: Theme.of(context).textTheme.bodySmall?.copyWith(
            color: Colors.grey.shade600,
            height: 1.3,
          ),
      maxLines: 2,
      overflow: TextOverflow.ellipsis,
    );
  }

  Widget _buildFooter(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            Icon(
              Icons.layers_outlined,
              size: 14,
              color: Colors.grey.shade500,
            ),
            const SizedBox(width: 4),
            Text(
              '${template.sectionCount} sections',
              style: TextStyle(
                fontSize: 12,
                color: Colors.grey.shade500,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
        Icon(
          Icons.arrow_forward_ios,
          size: 12,
          color: Colors.grey.shade400,
        ),
      ],
    );
  }
}
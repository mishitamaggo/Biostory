import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart' as auth;
import 'package:bionarrate/models/user.dart';

class UserService {
  static final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  static final auth.FirebaseAuth _auth = auth.FirebaseAuth.instance;
  
  static User? _currentUser;

  static Future<void> initialize() async {
    // Firebase handles user persistence automatically
    final firebaseUser = _auth.currentUser;
    if (firebaseUser != null) {
      _currentUser = await getUserById(firebaseUser.uid);
    }
  }


  static User? getCurrentUser() => _currentUser;

  static Future<void> setCurrentUser(User user) async {
    _currentUser = user;
    // Update user in Firestore
    await _firestore.collection('users').doc(user.id).set(user.toJson());
  }

  static Future<void> updateCurrentUser(User updatedUser) async {
    await setCurrentUser(updatedUser);
  }

  static Future<List<User>> getAllUsers() async {
    final snapshot = await _firestore.collection('users').get();
    return snapshot.docs.map((doc) => User.fromJson(doc.data())).toList();
  }

  static Future<User?> getUserById(String id) async {
    try {
      final doc = await _firestore.collection('users').doc(id).get();
      if (doc.exists && doc.data() != null) {
        return User.fromJson(doc.data()!);
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  static Future<void> incrementGenerationsUsed() async {
    if (_currentUser != null) {
      final updatedUser = _currentUser!.copyWith(
        generationsUsed: _currentUser!.generationsUsed + 1,
      );
      await updateCurrentUser(updatedUser);
    }
  }

  static Future<void> upgradeSubscription(String plan) async {
    if (_currentUser != null) {
      int newLimit;
      switch (plan) {
        case 'pro':
          newLimit = 50;
          break;
        case 'agency':
          newLimit = 200;
          break;
        default:
          newLimit = 3;
      }

      final updatedUser = _currentUser!.copyWith(
        subscriptionPlan: plan,
        generationsLimit: newLimit,
      );
      await updateCurrentUser(updatedUser);
    }
  }

  static Future<void> clearAllData() async {
    _currentUser = null;
  }

  static bool canGenerate() {
    return _currentUser?.hasGenerationsLeft ?? false;
  }

  static int getRemainingGenerations() {
    if (_currentUser == null) return 0;
    return (_currentUser!.generationsLimit - _currentUser!.generationsUsed).clamp(0, 999);
  }
}
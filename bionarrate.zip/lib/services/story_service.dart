import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart' as auth;
import 'package:bionarrate/models/story.dart';

class StoryService {
  static final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  static final auth.FirebaseAuth _auth = auth.FirebaseAuth.instance;

  static Future<void> initialize() async {
    // Firebase handles data persistence automatically
  }

  static Future<List<Story>> getAllStories() async {
    try {
      final snapshot = await _firestore.collection('stories')
          .orderBy('createdAt', descending: true)
          .get();
      return snapshot.docs.map((doc) => Story.fromJson(doc.data())).toList();
    } catch (e) {
      return [];
    }
  }

  static Future<List<Story>> getUserStories(String userId) async {
    try {
      final snapshot = await _firestore.collection('stories')
          .where('userId', isEqualTo: userId)
          .orderBy('createdAt', descending: true)
          .get();
      return snapshot.docs.map((doc) => Story.fromJson(doc.data())).toList();
    } catch (e) {
      return [];
    }
  }

  static Future<List<Story>> getStoriesForProject(String projectId) async {
    final user = _auth.currentUser;
    if (user == null) return [];
    
    try {
      final snapshot = await _firestore.collection('stories')
          .where('userId', isEqualTo: user.uid)
          .where('projectId', isEqualTo: projectId)
          .orderBy('createdAt', descending: true)
          .get();
      return snapshot.docs.map((doc) => Story.fromJson(doc.data())).toList();
    } catch (e) {
      return [];
    }
  }

  static Future<Story?> getStoryById(String id) async {
    try {
      final doc = await _firestore.collection('stories').doc(id).get();
      if (doc.exists && doc.data() != null) {
        return Story.fromJson(doc.data()!);
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  static Future<void> createStory(Story story) async {
    await _firestore.collection('stories').doc(story.id).set(story.toJson());
  }

  static Future<void> updateStory(Story updatedStory) async {
    await _firestore.collection('stories').doc(updatedStory.id).set(updatedStory.toJson());
  }

  static Future<void> deleteStory(String storyId) async {
    await _firestore.collection('stories').doc(storyId).delete();
  }

  static Future<List<Story>> getRecentStories({int limit = 5}) async {
    final user = _auth.currentUser;
    if (user == null) return [];
    
    try {
      final snapshot = await _firestore.collection('stories')
          .where('userId', isEqualTo: user.uid)
          .orderBy('createdAt', descending: true)
          .limit(limit)
          .get();
      return snapshot.docs.map((doc) => Story.fromJson(doc.data())).toList();
    } catch (e) {
      return [];
    }
  }

  static Future<Map<String, int>> getStoryStats() async {
    final user = _auth.currentUser;
    if (user == null) {
      return {'total': 0};
    }
    
    try {
      final snapshot = await _firestore.collection('stories')
          .where('userId', isEqualTo: user.uid)
          .get();
      
      return {'total': snapshot.docs.length};
    } catch (e) {
      return {'total': 0};
    }
  }

  static Future<void> clearAllData() async {
    // Firebase data is managed by security rules
  }
}
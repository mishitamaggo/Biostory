import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:bionarrate/models/template.dart';

class TemplateService {
  static final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  static Future<void> initialize() async {
    // Templates are managed by admins and pre-populated in Firebase
  }

  // Sample templates are managed by Firebase console
  static Future<void> _createSampleTemplates() async {
    final sampleTemplates = [
      Template.create(
        name: 'Investor Pitch Deck',
        description: 'Professional pitch deck template designed specifically for biotech startups seeking investment',
        category: TemplateCategory.pitch,
        thumbnailUrl: 'https://pixabay.com/get/gded810dd234b9acf7b55a5bab0a81bd2027c89c7c931cc7551ec9d961088773e1317ee39136bd40dc996468d2c9a4aef12ef374f7478a8d3b02180a09bd080de_1280.png',
        sectionTitles: [
          'Problem Statement',
          'Our Solution',
          'Science & Technology',
          'Market Opportunity',
          'Competitive Advantage',
          'Clinical Progress',
          'Business Model',
          'Team & Expertise',
          'Financial Projections',
          'Funding Requirements'
        ],
        styling: {
          'primaryColor': '#006B7D',
          'accentColor': '#00BCD4',
          'backgroundColor': '#FAFBFB',
        },
      ),
      Template.create(
        name: 'Grant Application',
        description: 'Comprehensive template for NIH, NSF, and other research grant applications',
        category: TemplateCategory.grant,
        thumbnailUrl: 'https://pixabay.com/get/gdcfd6448718c57ad68e10b0875d098cf605951b992419ed50b132471eeeb383a4e86494d2c4b922d6d65ad512efe8e9c1ce01d8567340903c3a2de3184ec6228_1280.jpg',
        sectionTitles: [
          'Research Significance',
          'Innovation & Impact',
          'Specific Aims',
          'Background & Rationale',
          'Methodology',
          'Preliminary Data',
          'Expected Outcomes',
          'Research Team',
          'Budget Justification',
          'Timeline & Milestones'
        ],
        styling: {
          'primaryColor': '#10B981',
          'accentColor': '#34D399',
          'backgroundColor': '#F0FDF4',
        },
      ),
      Template.create(
        name: 'Website Content',
        description: 'Clear, engaging website content that explains your biotech innovation to diverse audiences',
        category: TemplateCategory.website,
        thumbnailUrl: 'https://pixabay.com/get/g77ef1e599d3d11b3374f6d3472b571e8b314c985a00dbe6e10706a8c463d0e3b277cb8e5f4a75a2c3b7e230acf3d7654323567a5ddb33ac1f538b161525e5c09_1280.jpg',
        sectionTitles: [
          'Hero Statement',
          'The Problem We Solve',
          'Our Technology',
          'How It Works',
          'Clinical Evidence',
          'About Our Team',
          'Partner With Us',
          'News & Updates'
        ],
        styling: {
          'primaryColor': '#6366F1',
          'accentColor': '#8B5CF6',
          'backgroundColor': '#FAFAFB',
        },
      ),
      Template.create(
        name: 'Series A Presentation',
        description: 'Advanced investor presentation for Series A funding rounds with detailed market analysis',
        category: TemplateCategory.investor,
        thumbnailUrl: 'https://pixabay.com/get/g1711bf2dd2e10fd6619c00a4d8af7691e2d08fcd8f42077db75f4a8744a09c9b661e6e053103e0565bd90f3c70d3280034db89fe7d4ca235a77becdb6e9a5f19_1280.jpg',
        sectionTitles: [
          'Executive Summary',
          'Market Analysis',
          'Technology Deep Dive',
          'Regulatory Pathway',
          'IP Portfolio',
          'Clinical Development',
          'Go-to-Market Strategy',
          'Financial Model',
          'Investment Terms',
          'Use of Funds'
        ],
        isPremium: true,
        styling: {
          'primaryColor': '#DC2626',
          'accentColor': '#EF4444',
          'backgroundColor': '#FEF2F2',
        },
      ),
      Template.create(
        name: 'Partnership Proposal',
        description: 'Template for pharmaceutical partnerships and licensing deals',
        category: TemplateCategory.general,
        thumbnailUrl: 'https://pixabay.com/get/gbbaaf8e5a676c9ba7b44e246bd45a12b45a8938757e49407c4a79868a6d4eb180b2616124e50484aa9ff6a50dbfe69f5333805c7190ff765412ed4b62007e96f_1280.jpg',
        sectionTitles: [
          'Partnership Opportunity',
          'Our Technology',
          'Market Potential',
          'Collaboration Benefits',
          'Development Timeline',
          'Terms & Structure'
        ],
        isPremium: true,
        styling: {
          'primaryColor': '#7C3AED',
          'accentColor': '#A855F7',
          'backgroundColor': '#FAF5FF',
        },
      ),
    ];

    // Sample templates should be created in Firebase console
  }

  static Future<List<Template>> getAllTemplates() async {
    try {
      final snapshot = await _firestore.collection('templates').get();
      return snapshot.docs.map((doc) => Template.fromJson(doc.data())).toList();
    } catch (e) {
      return [];
    }
  }

  static Future<Template?> getTemplateById(String id) async {
    try {
      final doc = await _firestore.collection('templates').doc(id).get();
      if (doc.exists && doc.data() != null) {
        return Template.fromJson(doc.data()!);
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  static Future<List<Template>> getTemplatesByCategory(TemplateCategory category) async {
    final templates = await getAllTemplates();
    return templates.where((t) => t.category == category).toList();
  }

  static Future<List<Template>> getFreeTemplates() async {
    final templates = await getAllTemplates();
    return templates.where((t) => !t.isPremium).toList();
  }

  static Future<List<Template>> getPremiumTemplates() async {
    final templates = await getAllTemplates();
    return templates.where((t) => t.isPremium).toList();
  }

  static Future<void> createTemplate(Template template) async {
    await _firestore.collection('templates').doc(template.id).set(template.toJson());
  }

  static Future<void> updateTemplate(Template updatedTemplate) async {
    await _firestore.collection('templates').doc(updatedTemplate.id).set(updatedTemplate.toJson());
  }

  static Future<void> deleteTemplate(String templateId) async {
    await _firestore.collection('templates').doc(templateId).delete();
  }


  static Future<List<Template>> getPopularTemplates() async {
    final templates = await getAllTemplates();
    // Return most commonly used templates (for now, return first 3)
    return templates.take(3).toList();
  }

  static Future<void> clearAllData() async {
    // Templates are managed by security rules
  }

  static Future<Map<TemplateCategory, int>> getTemplateCounts() async {
    final templates = await getAllTemplates();
    final counts = <TemplateCategory, int>{};
    
    for (final category in TemplateCategory.values) {
      counts[category] = templates.where((t) => t.category == category).length;
    }
    
    return counts;
  }
}
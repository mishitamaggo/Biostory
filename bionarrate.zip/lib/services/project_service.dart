import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart' as auth;
import 'package:bionarrate/models/project.dart';
import 'package:bionarrate/services/user_service.dart';

class ProjectService {
  static final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  static final auth.FirebaseAuth _auth = auth.FirebaseAuth.instance;

  static Future<void> initialize() async {
    // Firebase handles data persistence automatically
  }


  static Future<List<Project>> getAllProjects() async {
    try {
      final snapshot = await _firestore.collection('projects')
          .orderBy('updatedAt', descending: true)
          .get();
      return snapshot.docs.map((doc) => Project.fromJson(doc.data())).toList();
    } catch (e) {
      return [];
    }
  }

  static Future<List<Project>> getUserProjects(String userId) async {
    try {
      final snapshot = await _firestore.collection('projects')
          .where('userId', isEqualTo: userId)
          .orderBy('createdAt', descending: true)
          .get();
      return snapshot.docs.map((doc) => Project.fromJson(doc.data())).toList();
    } catch (e) {
      return [];
    }
  }

  static Future<Project?> getProjectById(String id) async {
    try {
      final doc = await _firestore.collection('projects').doc(id).get();
      if (doc.exists && doc.data() != null) {
        return Project.fromJson(doc.data()!);
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  static Future<void> createProject(Project project) async {
    await _firestore.collection('projects').doc(project.id).set(project.toJson());
  }

  static Future<void> updateProject(Project updatedProject) async {
    await _firestore.collection('projects').doc(updatedProject.id).set(updatedProject.toJson());
  }

  static Future<void> deleteProject(String projectId) async {
    await _firestore.collection('projects').doc(projectId).delete();
  }


  static Future<List<Project>> getRecentProjects({int limit = 5}) async {
    final currentUser = UserService.getCurrentUser();
    if (currentUser == null) return [];
    
    final userProjects = await getUserProjects(currentUser.id);
    return userProjects.take(limit).toList();
  }

  static Future<List<Project>> getCompletedProjects() async {
    final currentUser = UserService.getCurrentUser();
    if (currentUser == null) return [];
    
    final userProjects = await getUserProjects(currentUser.id);
    return userProjects
        .where((p) => p.status == ProjectStatus.completed)
        .toList();
  }

  static Future<List<Project>> getProjectsByStatus(ProjectStatus status) async {
    final user = _auth.currentUser;
    if (user == null) return [];
    
    try {
      final snapshot = await _firestore.collection('projects')
          .where('userId', isEqualTo: user.uid)
          .where('status', isEqualTo: status.name)
          .orderBy('updatedAt', descending: true)
          .get();
      return snapshot.docs.map((doc) => Project.fromJson(doc.data())).toList();
    } catch (e) {
      return [];
    }
  }

  static Future<void> clearAllData() async {
    // Firebase data is managed by security rules
  }

  static Future<Map<String, int>> getProjectStats() async {
    final currentUser = UserService.getCurrentUser();
    if (currentUser == null) {
      return {
        'total': 0,
        'completed': 0,
        'processing': 0,
        'draft': 0,
      };
    }
    
    final userProjects = await getUserProjects(currentUser.id);
    
    return {
      'total': userProjects.length,
      'completed': userProjects.where((p) => p.status == ProjectStatus.completed).length,
      'processing': userProjects.where((p) => p.status == ProjectStatus.processing).length,
      'draft': userProjects.where((p) => p.status == ProjectStatus.draft).length,
    };
  }
}
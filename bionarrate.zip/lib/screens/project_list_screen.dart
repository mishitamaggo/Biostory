import 'package:flutter/material.dart';
import 'package:bionarrate/models/project.dart';
import 'package:bionarrate/services/project_service.dart';
import 'package:bionarrate/services/user_service.dart';
import 'package:bionarrate/widgets/project_card.dart';
import 'package:bionarrate/screens/create_project_screen.dart';

class ProjectListScreen extends StatefulWidget {
  const ProjectListScreen({super.key});

  @override
  State<ProjectListScreen> createState() => _ProjectListScreenState();
}

class _ProjectListScreenState extends State<ProjectListScreen> {
  List<Project> projects = [];
  List<Project> filteredProjects = [];
  ProjectStatus? selectedStatus;
  String searchQuery = '';
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadProjects();
  }

  Future<void> _loadProjects() async {
    final currentUser = UserService.getCurrentUser();
    if (currentUser == null) return;

    final userProjects = await ProjectService.getUserProjects(currentUser.id);
    
    setState(() {
      projects = userProjects;
      _applyFilters();
      isLoading = false;
    });
  }

  void _applyFilters() {
    filteredProjects = projects.where((project) {
      final matchesSearch = searchQuery.isEmpty ||
          project.title.toLowerCase().contains(searchQuery.toLowerCase()) ||
          project.description.toLowerCase().contains(searchQuery.toLowerCase());
      
      final matchesStatus = selectedStatus == null || project.status == selectedStatus;
      
      return matchesSearch && matchesStatus;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Projects'),
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          IconButton(
            onPressed: _showCreateProject,
            icon: const Icon(Icons.add),
          ),
        ],
      ),
      body: Column(
        children: [
          _buildSearchAndFilters(),
          Expanded(
            child: isLoading
                ? const Center(child: CircularProgressIndicator())
                : _buildProjectList(),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchAndFilters() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          TextField(
            decoration: InputDecoration(
              hintText: 'Search projects...',
              prefixIcon: const Icon(Icons.search),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              filled: true,
              fillColor: Colors.grey.shade50,
            ),
            onChanged: (value) {
              setState(() {
                searchQuery = value;
                _applyFilters();
              });
            },
          ),
          const SizedBox(height: 12),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                _buildFilterChip(
                  label: 'All',
                  isSelected: selectedStatus == null,
                  onTap: () => _setStatusFilter(null),
                ),
                const SizedBox(width: 8),
                _buildFilterChip(
                  label: 'Draft',
                  isSelected: selectedStatus == ProjectStatus.draft,
                  onTap: () => _setStatusFilter(ProjectStatus.draft),
                ),
                const SizedBox(width: 8),
                _buildFilterChip(
                  label: 'Processing',
                  isSelected: selectedStatus == ProjectStatus.processing,
                  onTap: () => _setStatusFilter(ProjectStatus.processing),
                ),
                const SizedBox(width: 8),
                _buildFilterChip(
                  label: 'Completed',
                  isSelected: selectedStatus == ProjectStatus.completed,
                  onTap: () => _setStatusFilter(ProjectStatus.completed),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterChip({
    required String label,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    return FilterChip(
      label: Text(label),
      selected: isSelected,
      onSelected: (_) => onTap(),
      backgroundColor: Colors.grey.shade100,
      selectedColor: Theme.of(context).colorScheme.primary.withValues(alpha: 0.2),
      checkmarkColor: Theme.of(context).colorScheme.primary,
      labelStyle: TextStyle(
        color: isSelected
            ? Theme.of(context).colorScheme.primary
            : Colors.grey.shade700,
        fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
      ),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
    );
  }

  Widget _buildProjectList() {
    if (filteredProjects.isEmpty && projects.isEmpty) {
      return _buildEmptyState();
    }

    if (filteredProjects.isEmpty) {
      return _buildNoResultsState();
    }

    return RefreshIndicator(
      onRefresh: _loadProjects,
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: filteredProjects.length,
        itemBuilder: (context, index) {
          final project = filteredProjects[index];
          return Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: ProjectCard(
              project: project,
              onTap: () => _openProject(project),
              onDelete: () => _showDeleteConfirmation(project),
            ),
          );
        },
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.science_outlined,
              size: 80,
              color: Colors.grey.shade400,
            ),
            const SizedBox(height: 24),
            Text(
              'No projects yet',
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                    color: Colors.grey.shade600,
                  ),
            ),
            const SizedBox(height: 12),
            Text(
              'Create your first biotech story to transform your research into compelling presentations',
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                    color: Colors.grey.shade500,
                  ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 32),
            ElevatedButton.icon(
              onPressed: _showCreateProject,
              icon: const Icon(Icons.add),
              label: const Text('Create First Project'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNoResultsState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.search_off,
              size: 64,
              color: Colors.grey.shade400,
            ),
            const SizedBox(height: 16),
            Text(
              'No projects found',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    color: Colors.grey.shade600,
                  ),
            ),
            const SizedBox(height: 8),
            Text(
              'Try adjusting your search or filters',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Colors.grey.shade500,
                  ),
            ),
            const SizedBox(height: 16),
            TextButton(
              onPressed: () {
                setState(() {
                  searchQuery = '';
                  selectedStatus = null;
                  _applyFilters();
                });
              },
              child: const Text('Clear Filters'),
            ),
          ],
        ),
      ),
    );
  }

  void _setStatusFilter(ProjectStatus? status) {
    setState(() {
      selectedStatus = status;
      _applyFilters();
    });
  }

  void _showCreateProject() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (context) => const CreateProjectScreen()),
    ).then((_) => _loadProjects());
  }

  void _openProject(Project project) {
    // TODO: Navigate to project details/editor
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Opening ${project.title}')),
    );
  }

  void _showDeleteConfirmation(Project project) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Project'),
        content: Text(
          'Are you sure you want to delete "${project.title}"? This action cannot be undone.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              _deleteProject(project);
            },
            style: TextButton.styleFrom(
              foregroundColor: Theme.of(context).colorScheme.error,
            ),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  Future<void> _deleteProject(Project project) async {
    try {
      await ProjectService.deleteProject(project.id);
      await _loadProjects();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Project deleted successfully')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error deleting project: $e')),
        );
      }
    }
  }
}
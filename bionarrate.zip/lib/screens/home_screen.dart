import 'package:flutter/material.dart';
import 'package:bionarrate/models/project.dart';
import 'package:bionarrate/models/user.dart';
import 'package:bionarrate/services/user_service.dart';
import 'package:bionarrate/services/project_service.dart';
import 'package:bionarrate/widgets/project_card.dart';
import 'package:bionarrate/screens/create_project_screen.dart';
import 'package:bionarrate/screens/project_list_screen.dart';
import 'package:bionarrate/screens/template_gallery_screen.dart';
import 'package:bionarrate/screens/analytics_screen.dart';
import 'package:bionarrate/auth/firebase_auth_manager.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  User? currentUser;
  List<Project> recentProjects = [];
  Map<String, int> projectStats = {};
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _initializeData();
  }

  Future<void> _initializeData() async {
    await UserService.initialize();
    await ProjectService.initialize();
    
    setState(() {
      currentUser = UserService.getCurrentUser();
    });
    
    await _loadData();
  }

  Future<void> _loadData() async {
    final projects = await ProjectService.getRecentProjects(limit: 3);
    final stats = await ProjectService.getProjectStats();
    
    setState(() {
      recentProjects = projects;
      projectStats = stats;
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: _loadData,
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildHeader(),
                const SizedBox(height: 32),
                _buildQuickActions(),
                const SizedBox(height: 32),
                _buildStatsCards(),
                const SizedBox(height: 32),
                _buildRecentProjects(),
                const SizedBox(height: 100), // Extra padding for FAB
              ],
            ),
          ),
        ),
      ),
      floatingActionButton: _buildCreateProjectFAB(),
    );
  }

  Widget _buildHeader() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(
              'BioStory AI',
              style: Theme.of(context).textTheme.displaySmall?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: Theme.of(context).colorScheme.primary,
                  ),
            ),
            const Spacer(),
            Tooltip(
              message: 'Sign out',
              child: TextButton.icon(
                onPressed: () async {
                  await FirebaseAuthManager().signOut();
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Signed out')));
                  }
                },
                icon: const Icon(Icons.logout, color: Colors.red),
                label: const Text('Sign out'),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Text(
          'Welcome back, ${currentUser?.name.split(' ').first ?? 'User'}! 👋',
          style: Theme.of(context).textTheme.headlineMedium,
        ),
        const SizedBox(height: 4),
        Text(
          'Transform your biotech research into compelling stories',
          style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                color: Colors.grey.shade600,
              ),
        ),
      ],
    );
  }

  Widget _buildQuickActions() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Quick Actions',
          style: Theme.of(context).textTheme.titleLarge,
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: _buildActionCard(
                icon: Icons.add_circle_outline,
                title: 'New Project',
                subtitle: 'Start converting your research',
                onTap: () => _navigateToCreateProject(),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: _buildActionCard(
                icon: Icons.dashboard_outlined,
                title: 'Templates',
                subtitle: 'Browse pitch templates',
                onTap: () => _navigateToTemplateGallery(),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildActionCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Card(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(
                icon,
                size: 32,
                color: Theme.of(context).colorScheme.primary,
              ),
              const SizedBox(height: 12),
              Text(
                title,
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
              ),
              const SizedBox(height: 4),
              Text(
                subtitle,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Colors.grey.shade600,
                    ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatsCards() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Your Progress',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            TextButton(
              onPressed: () => _navigateToAnalytics(),
              child: const Text('View All'),
            ),
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: _buildStatCard(
                value: '${projectStats['total'] ?? 0}',
                label: 'Projects',
                icon: Icons.folder_outlined,
                color: Theme.of(context).colorScheme.primary,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _buildStatCard(
                value: '${UserService.getRemainingGenerations()}',
                label: 'Generations Left',
                icon: Icons.auto_awesome,
                color: Theme.of(context).colorScheme.secondary,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _buildStatCard(
                value: '${projectStats['completed'] ?? 0}',
                label: 'Completed',
                icon: Icons.check_circle_outlined,
                color: Theme.of(context).colorScheme.tertiary,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildStatCard({
    required String value,
    required String label,
    required IconData icon,
    required Color color,
  }) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Icon(icon, color: color, size: 24),
            const SizedBox(height: 8),
            Text(
              value,
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: color,
                  ),
            ),
            Text(
              label,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Colors.grey.shade600,
                  ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRecentProjects() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Recent Projects',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            TextButton(
              onPressed: () => _navigateToProjectList(),
              child: const Text('View All'),
            ),
          ],
        ),
        const SizedBox(height: 16),
        if (recentProjects.isEmpty)
          _buildEmptyState()
        else
          ...recentProjects.map((project) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: ProjectCard(
                  project: project,
                  onTap: () => _openProject(project),
                ),
              )),
      ],
    );
  }

  Widget _buildEmptyState() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          children: [
            Icon(
              Icons.science_outlined,
              size: 64,
              color: Colors.grey.shade400,
            ),
            const SizedBox(height: 16),
            Text(
              'No projects yet',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    color: Colors.grey.shade600,
                  ),
            ),
            const SizedBox(height: 8),
            Text(
              'Create your first biotech story to get started',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Colors.grey.shade500,
                  ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCreateProjectFAB() {
    return FloatingActionButton.extended(
      onPressed: _navigateToCreateProject,
      icon: const Icon(Icons.add),
      label: const Text('Create Project'),
      backgroundColor: Theme.of(context).colorScheme.primary,
      foregroundColor: Theme.of(context).colorScheme.onPrimary,
    );
  }

  void _navigateToCreateProject() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (context) => const CreateProjectScreen()),
    );
  }

  void _navigateToProjectList() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (context) => const ProjectListScreen()),
    );
  }

  void _navigateToTemplateGallery() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (context) => const TemplateGalleryScreen()),
    );
  }

  void _navigateToAnalytics() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (context) => const AnalyticsScreen()),
    );
  }

  void _openProject(Project project) {
    // TODO: Navigate to project details/editor
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Opening ${project.title}')),
    );
  }
}
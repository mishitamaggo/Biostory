import 'package:bionarrate/auth/firebase_auth_manager.dart';
import 'package:bionarrate/screens/home_screen.dart';
import 'package:bionarrate/screens/auth/sign_in_screen.dart';
import 'package:bionarrate/services/user_service.dart';
import 'package:flutter/material.dart';

class AuthGate extends StatefulWidget {
  const AuthGate({super.key});

  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  bool _loading = true;
  bool _isSignedIn = false;

  @override
  void initState() {
    super.initState();
    _bootstrap();
  }

  Future<void> _bootstrap() async {
    await UserService.initialize();
    setState(() {
      _isSignedIn = UserService.getCurrentUser() != null;
      _loading = false;
    });
    // Listen to auth changes
    FirebaseAuthManager().authStateChanges().listen((user) {
      setState(() => _isSignedIn = user != null);
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    return _isSignedIn ? const HomeScreen() : const SignInScreen();
  }
}

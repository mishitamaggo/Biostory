import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

class OpenAIConfig {
  static const String apiKey = String.fromEnvironment('OPENAI_PROXY_API_KEY');
  static const String endpoint = String.fromEnvironment('OPENAI_PROXY_ENDPOINT');
  
  static const String gpt4o = 'gpt-4o';
  static const String gpt4oMini = 'gpt-4o-mini';
  static const String o3Mini = 'o3-mini';

  static Future<Map<String, dynamic>> makeRequest({
    required String model,
    required List<Map<String, dynamic>> messages,
    Map<String, dynamic>? responseFormat,
    double temperature = 0.7,
    int maxTokens = 2000,
  }) async {
    if (apiKey.isEmpty || endpoint.isEmpty) {
      throw Exception('OpenAI API key or endpoint not configured');
    }

    final body = {
      'model': model,
      'messages': messages,
      'temperature': temperature,
      'max_tokens': maxTokens,
      if (responseFormat != null) 'response_format': responseFormat,
    };

    try {
      final response = await http.post(
        Uri.parse(endpoint),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $apiKey',
        },
        body: utf8.encode(jsonEncode(body)),
      );

      if (response.statusCode == 200) {
        final decodedResponse = utf8.decode(response.bodyBytes);
        return jsonDecode(decodedResponse) as Map<String, dynamic>;
      } else {
        throw HttpException('HTTP ${response.statusCode}: ${response.body}');
      }
    } catch (e) {
      throw Exception('OpenAI API request failed: $e');
    }
  }

  static Future<String> generateText({
    required String prompt,
    String model = gpt4o,
    double temperature = 0.7,
  }) async {
    final messages = [
      {'role': 'user', 'content': prompt}
    ];

    final response = await makeRequest(
      model: model,
      messages: messages,
      temperature: temperature,
    );

    final choices = response['choices'] as List<dynamic>?;
    if (choices == null || choices.isEmpty) {
      throw Exception('No response from OpenAI API');
    }

    final message = choices[0]['message'] as Map<String, dynamic>?;
    return message?['content'] as String? ?? '';
  }

  static Future<Map<String, dynamic>> generateJSON({
    required String prompt,
    required String systemPrompt,
    String model = gpt4o,
    double temperature = 0.7,
  }) async {
    final messages = [
      {'role': 'system', 'content': '$systemPrompt Output the result as a JSON object.'},
      {'role': 'user', 'content': prompt}
    ];

    final response = await makeRequest(
      model: model,
      messages: messages,
      responseFormat: {'type': 'json_object'},
      temperature: temperature,
    );

    final choices = response['choices'] as List<dynamic>?;
    if (choices == null || choices.isEmpty) {
      throw Exception('No response from OpenAI API');
    }

    final message = choices[0]['message'] as Map<String, dynamic>?;
    final content = message?['content'] as String? ?? '{}';
    
    try {
      return jsonDecode(content) as Map<String, dynamic>;
    } catch (e) {
      throw Exception('Failed to parse JSON response: $e');
    }
  }

  static Future<String> analyzeBiotechDocument({
    required String documentContent,
  }) async {
    const systemPrompt = '''
You are a biotech communication expert specialized in translating complex scientific research into clear, investor-ready stories. 
Your task is to analyze biotech documents and extract key information for storytelling.

Focus on:
1. Core scientific innovation and technology
2. Market problem being solved
3. Competitive advantages
4. Potential impact and applications
5. Key scientific evidence or results
6. Target market and commercialization potential
''';

    final prompt = '''
Analyze this biotech document and extract the key information for creating an investor-ready story:

$documentContent

Please identify:
1. What is the core innovation/technology?
2. What problem does it solve?
3. What makes it unique/better?
4. What evidence supports its effectiveness?
5. What is the market potential?
6. Who are the target customers?
''';

    return await generateText(
      prompt: prompt,
      model: gpt4o,
      temperature: 0.3,
    );
  }

  static Future<Map<String, dynamic>> generateBiotechStory({
    required String analysis,
    required String templateSections,
  }) async {
    const systemPrompt = '''
You are an expert biotech storyteller who creates compelling, investor-ready presentations. 
Transform complex scientific concepts into clear, engaging narratives that non-experts can understand.
Create content that is professional, credible, and exciting.
''';

    final prompt = '''
Based on this biotech analysis, create a compelling story with the following sections: $templateSections

Analysis:
$analysis

For each section, provide:
1. A compelling title
2. Clear, jargon-free content that explains the concept simply
3. Key points that would interest investors
4. Suggested visuals or diagrams

Also provide a one-line explanation of what this biotech company does in plain English.
''';

    return await generateJSON(
      prompt: prompt,
      systemPrompt: systemPrompt,
      model: gpt4o,
      temperature: 0.4,
    );
  }

  static Future<String> generateOneLineExplanation({
    required String biotechDescription,
  }) async {
    final prompt = '''
Create a single, clear sentence that explains what this biotech company does in plain English that anyone can understand.

Description:
$biotechDescription

The one-line explanation should:
- Be under 20 words
- Avoid jargon and technical terms
- Focus on the benefit to people
- Be engaging and memorable

Examples of good one-liners:
- "We turn cancer cells into their own worst enemy"
- "We help paralyzed patients walk again using brain implants"
- "We grow organs in labs to save transplant patients"
''';

    return await generateText(
      prompt: prompt,
      model: gpt4oMini,
      temperature: 0.5,
    );
  }
}
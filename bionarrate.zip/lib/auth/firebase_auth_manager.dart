import 'package:firebase_auth/firebase_auth.dart' as auth;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:bionarrate/models/user.dart';
import 'package:bionarrate/auth/auth_manager.dart';
import 'package:flutter/material.dart';

class FirebaseAuthManager extends AuthManager {
  final auth.FirebaseAuth _firebaseAuth = auth.FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  @override
  Stream<User?> authStateChanges() {
    return _firebaseAuth.authStateChanges().asyncMap((firebaseUser) async {
      if (firebaseUser == null) return null;
      return await _getUserFromFirestore(firebaseUser.uid);
    });
  }

  @override
  Future<User?> getCurrentUser() async {
    final firebaseUser = _firebaseAuth.currentUser;
    if (firebaseUser == null) return null;
    return await _getUserFromFirestore(firebaseUser.uid);
  }

  @override
  Future<User?> signInWithEmail({
    required BuildContext context,
    required String email,
    required String password,
  }) async {
    try {
      final credential = await _firebaseAuth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      
      if (credential.user != null) {
        return await _getUserFromFirestore(credential.user!.uid);
      }
      return null;
    } on auth.FirebaseAuthException catch (e) {
      if (context.mounted) {
        _showAuthError(context, e);
      }
      return null;
    }
  }

  @override
  Future<User?> signUpWithEmail({
    required BuildContext context,
    required String name,
    required String email,
    required String password,
  }) async {
    try {
      final credential = await _firebaseAuth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      
      if (credential.user != null) {
        // Create user document in Firestore
        final user = User.create(
          name: name,
          email: email,
        );
        
        // Use Firebase Auth UID as our user ID
        final userWithAuthId = user.copyWith();
        final userDoc = userWithAuthId.toJson();
        userDoc['id'] = credential.user!.uid; // Override with Firebase Auth UID
        
        await _firestore
            .collection('users')
            .doc(credential.user!.uid)
            .set(userDoc);
        
        return User.fromJson(userDoc);
      }
      return null;
    } on auth.FirebaseAuthException catch (e) {
      if (context.mounted) {
        _showAuthError(context, e);
      }
      return null;
    }
  }

  @override
  Future<void> resetPassword({
    required BuildContext context,
    required String email,
  }) async {
    try {
      await _firebaseAuth.sendPasswordResetEmail(email: email);
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Password reset email sent! Check your inbox.'),
            backgroundColor: Colors.green,
          ),
        );
      }
    } on auth.FirebaseAuthException catch (e) {
      if (context.mounted) {
        _showAuthError(context, e);
      }
    }
  }

  @override
  Future<void> signOut() async {
    await _firebaseAuth.signOut();
  }

  Future<User?> _getUserFromFirestore(String uid) async {
    try {
      final doc = await _firestore.collection('users').doc(uid).get();
      if (doc.exists && doc.data() != null) {
        return User.fromJson(doc.data()!);
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  void _showAuthError(BuildContext context, auth.FirebaseAuthException e) {
    String message;
    switch (e.code) {
      case 'user-not-found':
        message = 'No user found with this email address.';
        break;
      case 'wrong-password':
        message = 'Invalid password.';
        break;
      case 'email-already-in-use':
        message = 'An account already exists with this email address.';
        break;
      case 'weak-password':
        message = 'Password is too weak. Please choose a stronger password.';
        break;
      case 'invalid-email':
        message = 'Invalid email address.';
        break;
      case 'too-many-requests':
        message = 'Too many failed attempts. Please try again later.';
        break;
      default:
        message = 'Authentication failed: ${e.message}';
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
      ),
    );
  }
}
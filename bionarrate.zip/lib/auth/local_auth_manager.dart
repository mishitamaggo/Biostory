import 'dart:async';
import 'dart:convert';

import 'package:bionarrate/auth/auth_manager.dart';
import 'package:bionarrate/models/user.dart' as app_user;
import 'package:bionarrate/services/user_service.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

/// Local email/password auth using SharedPreferences.
/// This is intended for prototype/demo. Replace with Firebase/Supabase in production.
class LocalAuthManager extends AuthManager {
  LocalAuthManager._internal();
  static final LocalAuthManager instance = LocalAuthManager._internal();

  static const _usersKey = 'auth_users'; // list of {id, name, email, password}
  static const _currentUserIdKey = 'auth_current_user_id';

  final _controller = StreamController<app_user.User?>.broadcast();

  @override
  Stream<app_user.User?> authStateChanges() => _controller.stream;

  @override
  Future<app_user.User?> getCurrentUser() async => UserService.getCurrentUser();

  Future<List<Map<String, dynamic>>> _getAuthUsers() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_usersKey);
    if (raw == null) return [];
    final list = jsonDecode(raw) as List<dynamic>;
    return list.cast<Map<String, dynamic>>();
  }

  Future<void> _saveAuthUsers(List<Map<String, dynamic>> users) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_usersKey, jsonEncode(users));
  }

  Future<void> _setCurrentUserId(String? id) async {
    final prefs = await SharedPreferences.getInstance();
    if (id == null) {
      await prefs.remove(_currentUserIdKey);
    } else {
      await prefs.setString(_currentUserIdKey, id);
    }
  }

  @override
  Future<app_user.User?> signInWithEmail({required BuildContext context, required String email, required String password}) async {
    final users = await _getAuthUsers();
    final match = users.cast<Map<String, dynamic>>().where((u) => (u['email'] as String).toLowerCase() == email.toLowerCase()).toList();
    if (match.isEmpty) {
      _showSnack(context, 'No account found for $email');
      return null;
    }
    final record = match.first;
    if (record['password'] != password) {
      _showSnack(context, 'Incorrect password');
      return null;
    }
    // Build app user and store with UserService
    final user = app_user.User(
      id: record['id'] as String,
      name: record['name'] as String,
      email: record['email'] as String,
      subscriptionPlan: record['subscriptionPlan'] as String? ?? 'free',
      createdAt: DateTime.parse(record['createdAt'] as String),
      updatedAt: DateTime.now(),
    );
    await UserService.setCurrentUser(user);
    await _setCurrentUserId(user.id);
    _controller.add(user);
    return user;
  }

  @override
  Future<app_user.User?> signUpWithEmail({required BuildContext context, required String name, required String email, required String password}) async {
    final users = await _getAuthUsers();
    final exists = users.any((u) => (u['email'] as String).toLowerCase() == email.toLowerCase());
    if (exists) {
      _showSnack(context, 'An account with this email already exists');
      return null;
    }
    final id = const Uuid().v4();
    final record = <String, dynamic>{
      'id': id,
      'name': name,
      'email': email,
      'password': password,
      'subscriptionPlan': 'free',
      'createdAt': DateTime.now().toIso8601String(),
    };
    users.add(record);
    await _saveAuthUsers(users);

    final user = app_user.User(
      id: id,
      name: name,
      email: email,
      subscriptionPlan: 'free',
      createdAt: DateTime.parse(record['createdAt'] as String),
      updatedAt: DateTime.now(),
    );
    await UserService.setCurrentUser(user);
    await _setCurrentUserId(user.id);
    _controller.add(user);
    return user;
  }

  @override
  Future<void> resetPassword({required BuildContext context, required String email}) async {
    final users = await _getAuthUsers();
    final index = users.indexWhere((u) => (u['email'] as String).toLowerCase() == email.toLowerCase());
    if (index == -1) {
      _showSnack(context, 'If the email exists, a reset link has been sent');
      return;
    }
    // For local auth, we just inform; no real email sending.
    _showSnack(context, 'Password reset link sent to $email');
  }

  @override
  Future<void> signOut() async {
    await _setCurrentUserId(null);
    await UserService.clearAllData();
    _controller.add(null);
  }

  void _showSnack(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }
}

import 'package:bionarrate/models/user.dart';
import 'package:flutter/material.dart';

/// Base authentication interface for the app.
/// Implementations can be local (mock), Firebase, or Supabase.
abstract class AuthManager {
  const AuthManager();

  /// Emits the current user and subsequent auth state changes.
  Stream<User?> authStateChanges();

  /// Returns the current user if signed in; null otherwise.
  Future<User?> getCurrentUser();

  /// Email/password operations
  Future<User?> signInWithEmail({required BuildContext context, required String email, required String password});
  Future<User?> signUpWithEmail({required BuildContext context, required String name, required String email, required String password});
  Future<void> resetPassword({required BuildContext context, required String email});

  /// Sign out
  Future<void> signOut();
}

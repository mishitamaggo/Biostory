# BioStory AI - Architecture Plan

## Overview
A sleek, modern SaaS web app that transforms complex biotech research into investor-ready stories. Features elegant design with generous spacing, modern typography, and beautiful gradients.

## Core Features (MVP)
1. **Landing Page** - Hero section with value proposition
2. **Dashboard** - Project management and overview
3. **Story Generator** - Upload research, generate stories
4. **Template Gallery** - Pre-built biotech pitch templates
5. **Story Editor** - Visual editor for generated content
6. **Settings** - User preferences and subscription

## Design System
- **Colors**: Modern biotech gradient (deep blues to teals)
- **Typography**: Inter font with generous spacing
- **Layout**: Card-based, minimal shadows, rounded corners
- **Animations**: Subtle transitions and micro-interactions

## Data Models
- User (name, email, subscription)
- Project (title, description, status, templates)
- Story (content, type, generation_date)
- Template (category, design, layout)

## File Structure
```
lib/
├── main.dart
├── theme.dart
├── models/
│   ├── user.dart
│   ├── project.dart
│   └── story.dart
├── screens/
│   ├── landing_page.dart
│   ├── dashboard_screen.dart
│   ├── story_generator_screen.dart
│   ├── template_gallery_screen.dart
│   ├── story_editor_screen.dart
│   └── settings_screen.dart
├── widgets/
│   ├── custom_card.dart
│   ├── gradient_button.dart
│   └── feature_showcase.dart
└── services/
    └── local_storage_service.dart
```

## Implementation Steps
1. Update theme with modern biotech colors and spacing
2. Create data models for core entities
3. Build landing page with hero section and features
4. Implement dashboard with project cards
5. Create story generator with upload interface
6. Build template gallery with biotech-specific templates
7. Add story editor with visual editing capabilities
8. Implement settings screen
9. Add navigation and routing
10. Test and compile project
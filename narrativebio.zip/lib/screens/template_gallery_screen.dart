import 'package:flutter/material.dart';
import 'package:narrativebio/models/story.dart';
import 'package:narrativebio/widgets/custom_card.dart';
import 'package:narrativebio/widgets/gradient_button.dart';

class TemplateGalleryScreen extends StatefulWidget {
  const TemplateGalleryScreen({super.key});

  @override
  State<TemplateGalleryScreen> createState() => _TemplateGalleryScreenState();
}

class _TemplateGalleryScreenState extends State<TemplateGalleryScreen> {
  String _selectedCategory = 'All';
  final List<String> _categories = ['All', 'Therapeutics', 'Diagnostics', 'Platform Technology', 'Medical Devices'];
  
  final List<StoryTemplate> _templates = [
    StoryTemplate(
      id: '1',
      name: 'Gene Therapy Investor Pitch',
      description: 'Perfect for CRISPR, gene editing, and gene therapy companies',
      type: StoryType.pitchDeck,
      category: 'Therapeutics',
      previewImageUrl: 'https://pixabay.com/get/g693e4f56c16f1cf5d6acd4b6538595588c50500a841c6f3e147c99410dc6abbb9898f24240ec7a6d0fc2bc45a3ade50e41fe1c5f3406fced432900086530de7e_1280.jpg',
      layout: {},
    ),
    StoryTemplate(
      id: '2',
      name: 'Biomarker Discovery Presentation',
      description: 'Showcase your diagnostic breakthroughs and clinical validation',
      type: StoryType.pitchDeck,
      category: 'Diagnostics',
      previewImageUrl: 'https://pixabay.com/get/gcf5aefb2646b639cc223a8a1f7903074b003287d69db33ff22228d29097b6ede4d19ea12513fd76e0e87af900dca5b1c555cd227bdd6015a23a1015a2a876c6b_1280.jpg',
      layout: {},
    ),
    StoryTemplate(
      id: '3',
      name: 'AI Drug Discovery Platform',
      description: 'Highlight your computational approach to drug development',
      type: StoryType.pitchDeck,
      category: 'Platform Technology',
      previewImageUrl: 'https://pixabay.com/get/g6c00e483ebf161206da3e94a7b64f863c363d18e7328054512ecb82a7f4d248e1168102c60ccdbfd7af00fe5ca556ede293a9ca9ed3d30d84844b987175bd974_1280.jpg',
      layout: {},
    ),
    StoryTemplate(
      id: '4',
      name: 'Medical Device Innovation',
      description: 'Perfect for breakthrough medical devices and healthcare tech',
      type: StoryType.pitchDeck,
      category: 'Medical Devices',
      previewImageUrl: 'https://pixabay.com/get/g191d19154e39a9631cb92880f947f9ad3fc37654265d663ff706792541c8693944784934604cb2ada0b71ad0801317aa21fb6c5e77110bb8a6e4e70a56a43750_1280.jpg',
      layout: {},
    ),
    StoryTemplate(
      id: '5',
      name: 'Immunotherapy Breakthrough',
      description: 'Designed for cancer immunotherapy and immune system therapeutics',
      type: StoryType.pitchDeck,
      category: 'Therapeutics',
      previewImageUrl: 'https://pixabay.com/get/gcf5aefb2646b639cc223a8a1f7903074b003287d69db33ff22228d29097b6ede4d19ea12513fd76e0e87af900dca5b1c555cd227bdd6015a23a1015a2a876c6b_1280.jpg',
      layout: {},
    ),
    StoryTemplate(
      id: '6',
      name: 'Precision Medicine Platform',
      description: 'Showcase personalized treatment approaches and patient stratification',
      type: StoryType.pitchDeck,
      category: 'Platform Technology',
      previewImageUrl: 'https://pixabay.com/get/g693e4f56c16f1cf5d6acd4b6538595588c50500a841c6f3e147c99410dc6abbb9898f24240ec7a6d0fc2bc45a3ade50e41fe1c5f3406fced432900086530de7e_1280.jpg',
      layout: {},
    ),
  ];

  List<StoryTemplate> get _filteredTemplates {
    if (_selectedCategory == 'All') return _templates;
    return _templates.where((template) => template.category == _selectedCategory).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(32),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Template Gallery',
            style: Theme.of(context).textTheme.displaySmall?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Professional, biotech-specific templates to elevate your presentations.',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
            ),
          ),
          const SizedBox(height: 32),
          _buildCategoryFilter(),
          const SizedBox(height: 32),
          Expanded(
            child: GridView.builder(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                crossAxisSpacing: 24,
                mainAxisSpacing: 24,
                childAspectRatio: 0.85,
              ),
              itemCount: _filteredTemplates.length,
              itemBuilder: (context, index) {
                final template = _filteredTemplates[index];
                return _TemplateCard(
                  template: template,
                  onUseTemplate: () => _useTemplate(template),
                  onPreview: () => _previewTemplate(template),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryFilter() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: _categories.map((category) {
          final isSelected = _selectedCategory == category;
          return Container(
            margin: const EdgeInsets.only(right: 12),
            child: GradientButton(
              text: category,
              size: GradientButtonSize.small,
              isOutlined: !isSelected,
              onPressed: () => setState(() => _selectedCategory = category),
            ),
          );
        }).toList(),
      ),
    );
  }

  void _useTemplate(StoryTemplate template) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Use Template: ${template.name}'),
        content: Text('This will create a new project using the ${template.name} template. You can customize it with your specific research content.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          GradientButton(
            text: 'Create Project',
            size: GradientButtonSize.small,
            onPressed: () {
              Navigator.pop(context);
              // Navigate to story generator with template pre-selected
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('New project created with ${template.name} template'),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  void _previewTemplate(StoryTemplate template) {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        child: Container(
          width: 800,
          height: 600,
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    template.name,
                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.close),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Expanded(
                child: Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.surfaceContainer,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.network(
                            template.previewImageUrl,
                            width: 300,
                            height: 200,
                            fit: BoxFit.cover,
                          ),
                        ),
                        const SizedBox(height: 16),
                        Text(
                          'Template Preview',
                          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          template.description,
                          textAlign: TextAlign.center,
                          style: Theme.of(context).textTheme.bodyLarge,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  GradientButton(
                    text: 'Use This Template',
                    onPressed: () {
                      Navigator.pop(context);
                      _useTemplate(template);
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TemplateCard extends StatelessWidget {
  final StoryTemplate template;
  final VoidCallback onUseTemplate;
  final VoidCallback onPreview;

  const _TemplateCard({
    required this.template,
    required this.onUseTemplate,
    required this.onPreview,
  });

  @override
  Widget build(BuildContext context) {
    return CustomCard(
      padding: EdgeInsets.zero,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            flex: 3,
            child: Stack(
              children: [
                ClipRRect(
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
                  child: Image.network(
                    template.previewImageUrl,
                    width: double.infinity,
                    height: double.infinity,
                    fit: BoxFit.cover,
                  ),
                ),
                Positioned(
                  top: 12,
                  right: 12,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.primary,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      template.category,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
                Positioned(
                  top: 12,
                  left: 12,
                  child: Material(
                    color: Colors.white.withValues(alpha: 0.9),
                    borderRadius: BorderRadius.circular(20),
                    child: InkWell(
                      onTap: onPreview,
                      borderRadius: BorderRadius.circular(20),
                      child: const Padding(
                        padding: EdgeInsets.all(8),
                        child: Icon(
                          Icons.visibility,
                          size: 16,
                          color: Colors.black,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            flex: 2,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    template.name,
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 8),
                  Expanded(
                    child: Text(
                      template.description,
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
                      ),
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: GradientButton(
                      text: 'Use Template',
                      size: GradientButtonSize.small,
                      onPressed: onUseTemplate,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
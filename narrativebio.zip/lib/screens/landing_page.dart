import 'package:flutter/material.dart';
import 'package:narrativebio/widgets/gradient_button.dart';
import 'package:narrativebio/widgets/custom_card.dart';
import 'package:narrativebio/screens/auth_screen.dart';
import 'package:narrativebio/screens/template_gallery_screen.dart';

class LandingPage extends StatelessWidget {
  const LandingPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            _buildHeroSection(context),
            const SizedBox(height: 80),
            _buildFeaturesSection(context),
            const SizedBox(height: 80),
            _buildHowItWorksSection(context),
            const SizedBox(height: 80),
            _buildCTASection(context),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Widget _buildHeroSection(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 80),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'BioStory AI',
                style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: Theme.of(context).colorScheme.primary,
                ),
              ),
              GradientButton(
                text: 'Get Started',
                size: GradientButtonSize.small,
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const AuthScreen()),
                ),
              ),
            ],
          ),
          const SizedBox(height: 80),
          Text(
            'Turns Complex Biotech Research\nInto Investor-Ready Stories',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.displaySmall?.copyWith(
              fontWeight: FontWeight.bold,
              height: 1.2,
              color: Theme.of(context).colorScheme.onSurface,
            ),
          ),
          const SizedBox(height: 24),
          Text(
            'Stop sounding like a PhD thesis. Transform your research into clear,\nvisual storytelling that investors and partners actually understand.',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
              color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
              height: 1.5,
            ),
          ),
          const SizedBox(height: 48),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              GradientButton(
                text: 'Start Free Trial',
                size: GradientButtonSize.large,
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const AuthScreen()),
                ),
              ),
              const SizedBox(width: 24),
              GradientButton(
                text: 'Watch Demo',
                size: GradientButtonSize.large,
                isOutlined: true,
                onPressed: () {
                  showDialog(
                    context: context,
                    builder: (context) => AlertDialog(
                      title: const Text('Watch Demo'),
                      content: const Text('A product walkthrough video will appear here. Demo coming soon!'),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: const Text('Close'),
                        ),
                        GradientButton(
                          text: 'Explore Templates',
                          size: GradientButtonSize.small,
                          onPressed: () {
                            Navigator.pop(context);
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => const TemplateGalleryScreen()),
                            );
                          },
                        ),
                      ],
                    ),
                  );
                },
              ),
            ],
          ),
          const SizedBox(height: 80),
          InkWell(
            borderRadius: BorderRadius.circular(16),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const TemplateGalleryScreen()),
              );
            },
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: Image.network(
                'https://pixabay.com/get/gcf5aefb2646b639cc223a8a1f7903074b003287d69db33ff22228d29097b6ede4d19ea12513fd76e0e87af900dca5b1c555cd227bdd6015a23a1015a2a876c6b_1280.jpg',
                height: 400,
                width: double.infinity,
                fit: BoxFit.cover,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFeaturesSection(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 32),
      child: Column(
        children: [
          Text(
            'Why Biotech Founders Choose BioStory AI',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.displaySmall?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 48),
          Row(
            children: [
              Expanded(
                child: _FeatureCard(
                  icon: Icons.auto_stories,
                  title: 'Clear Storytelling Decks',
                  description: 'Transform dense research into compelling visual narratives that investors can follow.',
                  imageUrl: 'https://pixabay.com/get/g6c00e483ebf161206da3e94a7b64f863c363d18e7328054512ecb82a7f4d248e1168102c60ccdbfd7af00fe5ca556ede293a9ca9ed3d30d84844b987175bd974_1280.jpg',
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const TemplateGalleryScreen()),
                  ),
                ),
              ),
              const SizedBox(width: 32),
              Expanded(
                child: _FeatureCard(
                  icon: Icons.lightbulb_outline,
                  title: 'One-Line Explanations',
                  description: 'Get crystal clear summaries: "What this biotech does in plain English".',
                  imageUrl: 'https://pixabay.com/get/g693e4f56c16f1cf5d6acd4b6538595588c50500a841c6f3e147c99410dc6abbb9898f24240ec7a6d0fc2bc45a3ade50e41fe1c5f3406fced432900086530de7e_1280.jpg',
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const TemplateGalleryScreen()),
                  ),
                ),
              ),
              const SizedBox(width: 32),
              Expanded(
                child: _FeatureCard(
                  icon: Icons.palette,
                  title: 'Branded Templates',
                  description: 'Professional pitch templates with biotech-specific visuals and layouts.',
                  imageUrl: 'https://pixabay.com/get/g191d19154e39a9631cb92880f947f9ad3fc37654265d663ff706792541c8693944784934604cb2ada0b71ad0801317aa21fb6c5e77110bb8a6e4e70a56a43750_1280.jpg',
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const TemplateGalleryScreen()),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildHowItWorksSection(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 60),
      color: Theme.of(context).colorScheme.surfaceContainer,
      child: Column(
        children: [
          Text(
            'How It Works',
            style: Theme.of(context).textTheme.displaySmall?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 48),
          Row(
            children: [
              Expanded(
                child: _StepCard(
                  stepNumber: '1',
                  title: 'Upload Research',
                  description: 'Drop your research papers, pitch decks, or grant applications.',
                ),
              ),
              const SizedBox(width: 32),
              Expanded(
                child: _StepCard(
                  stepNumber: '2',
                  title: 'AI Processing',
                  description: 'Our biotech-trained AI extracts key insights and narratives.',
                ),
              ),
              const SizedBox(width: 32),
              Expanded(
                child: _StepCard(
                  stepNumber: '3',
                  title: 'Get Stories',
                  description: 'Receive clear, investor-ready stories and visual decks.',
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildCTASection(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 32),
      child: CustomCard(
        backgroundColor: Theme.of(context).colorScheme.primaryContainer,
        child: Column(
          children: [
            Text(
              'Ready to Transform Your Biotech Story?',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'Join hundreds of biotech founders who\'ve made their research investor-ready',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                color: Theme.of(context).colorScheme.onPrimaryContainer.withValues(alpha: 0.8),
              ),
            ),
            const SizedBox(height: 32),
            GradientButton(
              text: 'Start Your Free Trial',
              size: GradientButtonSize.large,
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const AuthScreen()),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _FeatureCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String description;
  final String imageUrl;
  final VoidCallback? onTap;

  const _FeatureCard({
    required this.icon,
    required this.title,
    required this.description,
    required this.imageUrl,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return CustomCard(
      onTap: onTap,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Image.network(
              imageUrl,
              height: 200,
              width: double.infinity,
              fit: BoxFit.cover,
            ),
          ),
          const SizedBox(height: 20),
          Icon(
            icon,
            size: 32,
            color: Theme.of(context).colorScheme.primary,
          ),
          const SizedBox(height: 16),
          Text(
            title,
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),
          Text(
            description,
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
              color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
              height: 1.5,
            ),
          ),
        ],
      ),
    );
  }
}

class _StepCard extends StatelessWidget {
  final String stepNumber;
  final String title;
  final String description;

  const _StepCard({
    required this.stepNumber,
    required this.title,
    required this.description,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: 60,
          height: 60,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Theme.of(context).colorScheme.primary,
                Theme.of(context).colorScheme.secondary,
              ],
            ),
            shape: BoxShape.circle,
          ),
          child: Center(
            child: Text(
              stepNumber,
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
        const SizedBox(height: 20),
        Text(
          title,
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.bold,
          ),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 12),
        Text(
          description,
          style: Theme.of(context).textTheme.bodyLarge?.copyWith(
            color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
            height: 1.5,
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }
}
import 'package:flutter/material.dart';
import 'package:narrativebio/widgets/custom_card.dart';
import 'package:narrativebio/widgets/gradient_button.dart';
import 'package:narrativebio/models/story.dart';

class StoryGeneratorScreen extends StatefulWidget {
  const StoryGeneratorScreen({super.key});

  @override
  State<StoryGeneratorScreen> createState() => _StoryGeneratorScreenState();
}

class _StoryGeneratorScreenState extends State<StoryGeneratorScreen> {
  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _researchController = TextEditingController();
  StoryType _selectedStoryType = StoryType.pitchDeck;
  bool _isGenerating = false;
  String? _generatedStory;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(32),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Story Generator',
            style: Theme.of(context).textTheme.displaySmall?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Transform your biotech research into compelling stories.',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
            ),
          ),
          const SizedBox(height: 32),
          Expanded(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  flex: 2,
                  child: _buildInputForm(context),
                ),
                const SizedBox(width: 32),
                Expanded(
                  flex: 3,
                  child: _buildOutputSection(context),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInputForm(BuildContext context) {
    return CustomCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Project Information',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 24),
          _buildTextField(
            controller: _titleController,
            label: 'Project Title',
            hint: 'e.g., CRISPR Gene Therapy Platform',
          ),
          const SizedBox(height: 16),
          _buildTextField(
            controller: _descriptionController,
            label: 'Brief Description',
            hint: 'What problem does your biotech solve?',
            maxLines: 3,
          ),
          const SizedBox(height: 24),
          Text(
            'Story Type',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 12),
          ...StoryType.values.map((type) => _buildStoryTypeOption(type)),
          const SizedBox(height: 24),
          _buildTextField(
            controller: _researchController,
            label: 'Research Content',
            hint: 'Paste your research paper, grant application, or pitch deck content here...',
            maxLines: 8,
          ),
          const SizedBox(height: 32),
          SizedBox(
            width: double.infinity,
            child: GradientButton(
              text: _isGenerating ? 'Generating...' : 'Generate Story',
              isLoading: _isGenerating,
              onPressed: _isGenerating ? null : _generateStory,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOutputSection(BuildContext context) {
    return CustomCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Generated Story',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              if (_generatedStory != null)
                Row(
                  children: [
                    GradientButton(
                      text: 'Edit',
                      size: GradientButtonSize.small,
                      isOutlined: true,
                      onPressed: () {},
                    ),
                    const SizedBox(width: 8),
                    GradientButton(
                      text: 'Export',
                      size: GradientButtonSize.small,
                      onPressed: () {},
                    ),
                  ],
                ),
            ],
          ),
          const SizedBox(height: 24),
          Expanded(
            child: _generatedStory != null
                ? _buildGeneratedContent()
                : _buildEmptyState(),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required String hint,
    int maxLines = 1,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: controller,
          maxLines: maxLines,
          decoration: InputDecoration(
            hintText: hint,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(
                color: Theme.of(context).colorScheme.outline.withValues(alpha: 0.3),
              ),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(
                color: Theme.of(context).colorScheme.primary,
                width: 2,
              ),
            ),
            contentPadding: const EdgeInsets.all(16),
          ),
        ),
      ],
    );
  }

  Widget _buildStoryTypeOption(StoryType type) {
    final isSelected = _selectedStoryType == type;
    final title = switch (type) {
      StoryType.oneLiner => 'One-Line Explanation',
      StoryType.pitchDeck => 'Pitch Deck',
      StoryType.grantApplication => 'Grant Application',
      StoryType.websiteCopy => 'Website Copy',
    };

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () => setState(() => _selectedStoryType = type),
          borderRadius: BorderRadius.circular(12),
          child: Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: isSelected 
                  ? Theme.of(context).colorScheme.primaryContainer
                  : Colors.transparent,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: isSelected
                    ? Theme.of(context).colorScheme.primary
                    : Theme.of(context).colorScheme.outline.withValues(alpha: 0.3),
              ),
            ),
            child: Row(
              children: [
                Icon(
                  isSelected ? Icons.radio_button_checked : Icons.radio_button_unchecked,
                  color: isSelected 
                      ? Theme.of(context).colorScheme.primary
                      : Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.5),
                ),
                const SizedBox(width: 12),
                Text(
                  title,
                  style: TextStyle(
                    color: isSelected 
                        ? Theme.of(context).colorScheme.primary
                        : Theme.of(context).colorScheme.onSurface,
                    fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildGeneratedContent() {
    return SingleChildScrollView(
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surfaceContainer,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              _getStoryTypeTitle(),
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
                color: Theme.of(context).colorScheme.primary,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              _generatedStory!,
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                height: 1.6,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.auto_stories,
            size: 64,
            color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.3),
          ),
          const SizedBox(height: 16),
          Text(
            'No story generated yet',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
              color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.5),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Fill out the form and click "Generate Story" to get started.',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.5),
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  String _getStoryTypeTitle() {
    return switch (_selectedStoryType) {
      StoryType.oneLiner => 'One-Line Explanation',
      StoryType.pitchDeck => 'Investor Pitch Deck',
      StoryType.grantApplication => 'Grant Application Summary',
      StoryType.websiteCopy => 'Website Copy',
    };
  }

  void _generateStory() async {
    if (_titleController.text.isEmpty || _researchController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please fill in the project title and research content.'),
        ),
      );
      return;
    }

    setState(() => _isGenerating = true);

    // Simulate AI generation delay
    await Future.delayed(const Duration(seconds: 3));

    // Generate sample story based on type
    final story = _generateSampleStory();
    
    setState(() {
      _isGenerating = false;
      _generatedStory = story;
    });
  }

  String _generateSampleStory() {
    final title = _titleController.text;
    
    return switch (_selectedStoryType) {
      StoryType.oneLiner => 
        "We've developed a breakthrough CRISPR-based gene therapy that precisely corrects genetic mutations, offering hope to millions with inherited diseases.",
      
      StoryType.pitchDeck => '''
## Executive Summary
$title represents a revolutionary approach to treating inherited diseases through precision gene editing.

## The Problem
- 350+ million people worldwide suffer from rare genetic diseases
- Current treatments only manage symptoms, never cure
- Families face lifelong medical costs averaging \$1.2M per patient

## Our Solution
Our proprietary CRISPR platform delivers:
- 99.7% accuracy in gene correction
- Single-treatment cure potential
- Reduced manufacturing costs by 80%

## Market Opportunity
- \$180B rare disease market growing 12% annually
- First-mover advantage in 15+ disease indications
- Clear regulatory pathway via FDA Breakthrough Designation

## Competitive Advantage
- Patent-protected delivery system
- Exclusive partnerships with top research institutions
- World-class scientific advisory board

## Financial Projections
- \$50M Series A to complete Phase I trials
- Break-even by Year 5
- Projected \$2B valuation at IPO

## Next Steps
We're seeking strategic investors to accelerate clinical development and bring hope to patients waiting for a cure.''',
      
      StoryType.grantApplication => '''
## Project Summary
This proposal outlines the development of a next-generation CRISPR gene therapy platform for treating inherited diseases with unprecedented precision and safety.

## Specific Aims
1. Develop and validate enhanced CRISPR delivery systems
2. Demonstrate safety and efficacy in disease-relevant models
3. Prepare for first-in-human clinical trials

## Innovation and Significance
Our approach addresses critical limitations in current gene therapies through:
- Novel delivery mechanisms that reduce off-target effects
- Streamlined manufacturing processes
- Potential single-treatment cures for previously incurable diseases

## Expected Outcomes
This research will advance the field of gene therapy and provide new treatment options for patients with devastating genetic conditions.''',
      
      StoryType.websiteCopy => '''
# Transforming Lives Through Precision Gene Therapy

At $title, we're pioneering the future of genetic medicine. Our breakthrough CRISPR technology offers hope to millions suffering from inherited diseases.

## Why Choose Our Approach?

**Precision**: 99.7% accuracy in correcting genetic defects
**Safety**: Minimal off-target effects through proprietary targeting
**Accessibility**: Streamlined manufacturing reduces costs by 80%

## Our Mission
To cure genetic diseases, not just treat symptoms. Every patient deserves the chance at a healthy life.

**Ready to learn more?** Contact our team to discuss partnership opportunities and clinical trial information.''',
    };
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _researchController.dispose();
    super.dispose();
  }
}
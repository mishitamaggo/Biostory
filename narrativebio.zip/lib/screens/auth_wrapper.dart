import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:narrativebio/screens/auth_screen.dart';
import 'package:narrativebio/screens/dashboard_screen.dart';
import 'package:narrativebio/screens/landing_page.dart';
import 'package:narrativebio/supabase/supabase_config.dart';

class AuthWrapper extends StatefulWidget {
  const AuthWrapper({super.key});

  @override
  State<AuthWrapper> createState() => _AuthWrapperState();
}

class _AuthWrapperState extends State<AuthWrapper> {
  User? _user;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _initializeAuth();
    
    // Listen to auth state changes
    SupabaseAuth.authStateChanges.listen((AuthState data) {
      if (mounted) {
        setState(() {
          _user = data.session?.user;
        });
      }
    });
  }

  Future<void> _initializeAuth() async {
    await Future.delayed(Duration.zero); // Ensure widgets are built
    
    if (mounted) {
      setState(() {
        _user = SupabaseAuth.currentUser;
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    // If user is authenticated, show dashboard
    if (_user != null) {
      return const DashboardScreen();
    }

    // If no user, show landing page (which has auth options)
    return const LandingPage();
  }
}
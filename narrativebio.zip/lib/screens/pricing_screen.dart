import 'package:flutter/material.dart';
import 'package:narrativebio/widgets/custom_card.dart';
import 'package:narrativebio/widgets/gradient_button.dart';

class PricingScreen extends StatelessWidget {
  const PricingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Pricing'),
        centerTitle: false,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(32),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Choose the plan that fits your team',
              style: Theme.of(context).textTheme.displaySmall?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            const SizedBox(height: 8),
            Text(
              'Transparent pricing in ₹ (INR). Upgrade or downgrade anytime. No hidden fees.',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
                  ),
            ),
            const SizedBox(height: 32),
            _PlansRow(),
            const SizedBox(height: 40),
            _FAQBlock(),
          ],
        ),
      ),
    );
  }
}

class _PlansRow extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final isNarrow = constraints.maxWidth < 1000;
        final children = <Widget>[
          Expanded(child: _PlanCard.basic()),
          SizedBox(width: isNarrow ? 0 : 24, height: isNarrow ? 24 : 0),
          Expanded(child: _PlanCard.pro()),
          SizedBox(width: isNarrow ? 0 : 24, height: isNarrow ? 24 : 0),
          Expanded(child: _PlanCard.enterprise()),
        ];
        if (isNarrow) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: children,
          );
        }
        return Row(children: children);
      },
    );
  }
}

class _PlanCard extends StatelessWidget {
  final String title;
  final String price;
  final String cadence;
  final List<String> features;
  final String note;
  final String cta;
  final bool highlighted;
  final VoidCallback onPressed;
  final String? badgeText;

  const _PlanCard({
    required this.title,
    required this.price,
    required this.cadence,
    required this.features,
    required this.note,
    required this.cta,
    required this.highlighted,
    required this.onPressed,
    this.badgeText,
    super.key,
  });

  factory _PlanCard.basic() {
    return _PlanCard(
      title: 'Basic',
      price: '₹999',
      cadence: '/month',
      features: const [
        '3 BioStories / month',
        'PDF output',
        'Standard templates',
      ],
      note: 'For early founders / researchers',
      cta: 'Choose Basic',
      highlighted: false,
      onPressed: _noop,
    );
  }

  factory _PlanCard.pro() {
    return _PlanCard(
      title: 'Pro',
      price: '₹2,499',
      cadence: '/month',
      features: const [
        '10 BioStories / month',
        'Branded slide outline',
        'Priority support',
      ],
      note: 'Most popular; small startups & accelerators',
      cta: 'Choose Pro',
      highlighted: true,
      onPressed: _noop,
      badgeText: 'Most Popular',
    );
  }

  factory _PlanCard.enterprise() {
    return _PlanCard(
      title: 'Enterprise',
      price: '₹5,999+',
      cadence: '/month',
      features: const [
        'Unlimited stories',
        'Custom templates',
        'Bulk uploads',
      ],
      note: 'For incubators, accelerators, agencies',
      cta: 'Contact Sales',
      highlighted: false,
      onPressed: _noop,
    );
  }

  static void _noop() {}

  @override
  Widget build(BuildContext context) {
    final card = CustomCard(
      backgroundColor: highlighted
          ? Theme.of(context).colorScheme.primaryContainer
          : null,
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                title,
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
              ),
              const SizedBox(width: 8),
              if (badgeText != null)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.secondary.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Text(
                    badgeText!,
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.secondary,
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                price,
                style: Theme.of(context).textTheme.displaySmall?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
              ),
              const SizedBox(width: 6),
              Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Text(
                  cadence,
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
                      ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          ...features.map((f) => Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Row(
                  children: [
                    Icon(
                      Icons.check_circle,
                      size: 18,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        f,
                        style: Theme.of(context).textTheme.bodyMedium,
                      ),
                    ),
                  ],
                ),
              )),
          const SizedBox(height: 12),
          Text(
            note,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
                ),
          ),
          const SizedBox(height: 20),
          GradientButton(
            text: cta,
            onPressed: () {
              _handleSelect(context);
            },
          ),
        ],
      ),
    );

    return card;
  }

  void _handleSelect(BuildContext context) {
    // Placeholder action until billing/checkout is integrated.
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Selected $title plan. Checkout coming soon.'),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }
}

class _FAQBlock extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'FAQ',
          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.bold,
              ),
        ),
        const SizedBox(height: 16),
        _faqItem(
          context,
          'Can I change plans later?',
          'Yes. You can upgrade or downgrade anytime. Changes take effect immediately and are pro‑rated.',
        ),
        const SizedBox(height: 12),
        _faqItem(
          context,
          'Do you offer refunds?',
          'We offer a 7‑day free trial. You can cancel before it ends. After that, monthly payments are non‑refundable.',
        ),
        const SizedBox(height: 12),
        _faqItem(
          context,
          'How does the story limit work?',
          'Your monthly story allowance resets every billing cycle. You can generate drafts and final PDFs within your quota.',
        ),
      ],
    );
  }

  Widget _faqItem(BuildContext context, String q, String a) {
    return CustomCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            q,
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
          ),
          const SizedBox(height: 6),
          Text(
            a,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.75),
                ),
          ),
        ],
      ),
    );
  }
}

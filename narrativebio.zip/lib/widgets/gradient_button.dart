import 'package:flutter/material.dart';

enum GradientButtonSize { small, medium, large }

class GradientButton extends StatelessWidget {
  final String text;
  final VoidCallback? onPressed;
  final GradientButtonSize size;
  final bool isOutlined;
  final Widget? icon;
  final bool isLoading;

  const GradientButton({
    super.key,
    required this.text,
    this.onPressed,
    this.size = GradientButtonSize.medium,
    this.isOutlined = false,
    this.icon,
    this.isLoading = false,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    final height = switch (size) {
      GradientButtonSize.small => 40.0,
      GradientButtonSize.medium => 48.0,
      GradientButtonSize.large => 56.0,
    };

    final fontSize = switch (size) {
      GradientButtonSize.small => 14.0,
      GradientButtonSize.medium => 16.0,
      GradientButtonSize.large => 18.0,
    };

    final padding = switch (size) {
      GradientButtonSize.small => const EdgeInsets.symmetric(horizontal: 16),
      GradientButtonSize.medium => const EdgeInsets.symmetric(horizontal: 24),
      GradientButtonSize.large => const EdgeInsets.symmetric(horizontal: 32),
    };

    Widget buttonChild = Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (icon != null) ...[
          icon!,
          const SizedBox(width: 8),
        ],
        if (isLoading)
          SizedBox(
            width: 16,
            height: 16,
            child: CircularProgressIndicator(
              strokeWidth: 2,
              valueColor: AlwaysStoppedAnimation(
                isOutlined ? theme.colorScheme.primary : Colors.white,
              ),
            ),
          )
        else
          Text(
            text,
            style: TextStyle(
              fontSize: fontSize,
              fontWeight: FontWeight.w600,
              color: isOutlined ? theme.colorScheme.primary : Colors.white,
            ),
          ),
      ],
    );

    if (isOutlined) {
      return Container(
        height: height,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(height / 2),
          border: Border.all(
            color: theme.colorScheme.primary,
            width: 2,
          ),
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: onPressed,
            borderRadius: BorderRadius.circular(height / 2),
            child: Container(
              padding: padding,
              child: Center(child: buttonChild),
            ),
          ),
        ),
      );
    }

    return Container(
      height: height,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            theme.colorScheme.primary,
            theme.colorScheme.secondary,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(height / 2),
        boxShadow: [
          BoxShadow(
            color: theme.colorScheme.primary.withValues(alpha: 0.3),
            blurRadius: 12,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onPressed,
          borderRadius: BorderRadius.circular(height / 2),
          child: Container(
            padding: padding,
            child: Center(child: buttonChild),
          ),
        ),
      ),
    );
  }
}
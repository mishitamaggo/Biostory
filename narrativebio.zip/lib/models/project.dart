enum ProjectStatus { draft, generating, completed, archived }

class Project {
  final String id;
  final String title;
  final String description;
  final ProjectStatus status;
  final String? researchContent;
  final String? generatedStory;
  final String? selectedTemplate;
  final DateTime createdAt;
  final DateTime updatedAt;

  const Project({
    required this.id,
    required this.title,
    required this.description,
    required this.status,
    this.researchContent,
    this.generatedStory,
    this.selectedTemplate,
    required this.createdAt,
    required this.updatedAt,
  });

  factory Project.fromJson(Map<String, dynamic> json) => Project(
    id: json['id'],
    title: json['title'],
    description: json['description'],
    status: ProjectStatus.values.byName(json['status']),
    researchContent: json['researchContent'],
    generatedStory: json['generatedStory'],
    selectedTemplate: json['selectedTemplate'],
    createdAt: DateTime.parse(json['createdAt']),
    updatedAt: DateTime.parse(json['updatedAt']),
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'description': description,
    'status': status.name,
    'researchContent': researchContent,
    'generatedStory': generatedStory,
    'selectedTemplate': selectedTemplate,
    'createdAt': createdAt.toIso8601String(),
    'updatedAt': updatedAt.toIso8601String(),
  };

  Project copyWith({
    String? title,
    String? description,
    ProjectStatus? status,
    String? researchContent,
    String? generatedStory,
    String? selectedTemplate,
    DateTime? updatedAt,
  }) => Project(
    id: id,
    title: title ?? this.title,
    description: description ?? this.description,
    status: status ?? this.status,
    researchContent: researchContent ?? this.researchContent,
    generatedStory: generatedStory ?? this.generatedStory,
    selectedTemplate: selectedTemplate ?? this.selectedTemplate,
    createdAt: createdAt,
    updatedAt: updatedAt ?? DateTime.now(),
  );
}
class User {
  final String id;
  final String name;
  final String email;
  final String subscriptionTier;
  final DateTime joinDate;

  const User({
    required this.id,
    required this.name,
    required this.email,
    required this.subscriptionTier,
    required this.joinDate,
  });

  factory User.fromJson(Map<String, dynamic> json) => User(
    id: json['id'],
    name: json['name'],
    email: json['email'],
    subscriptionTier: json['subscriptionTier'],
    joinDate: DateTime.parse(json['joinDate']),
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'email': email,
    'subscriptionTier': subscriptionTier,
    'joinDate': joinDate.toIso8601String(),
  };
}
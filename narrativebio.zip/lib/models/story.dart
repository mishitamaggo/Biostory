enum StoryType { oneLiner, pitchDeck, grantApplication, websiteCopy }

class Story {
  final String id;
  final String projectId;
  final StoryType type;
  final String title;
  final String content;
  final Map<String, dynamic>? metadata;
  final DateTime generatedAt;

  const Story({
    required this.id,
    required this.projectId,
    required this.type,
    required this.title,
    required this.content,
    this.metadata,
    required this.generatedAt,
  });

  factory Story.fromJson(Map<String, dynamic> json) => Story(
    id: json['id'],
    projectId: json['projectId'],
    type: StoryType.values.byName(json['type']),
    title: json['title'],
    content: json['content'],
    metadata: json['metadata']?.cast<String, dynamic>(),
    generatedAt: DateTime.parse(json['generatedAt']),
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'projectId': projectId,
    'type': type.name,
    'title': title,
    'content': content,
    'metadata': metadata,
    'generatedAt': generatedAt.toIso8601String(),
  };
}

class StoryTemplate {
  final String id;
  final String name;
  final String description;
  final StoryType type;
  final String category;
  final String previewImageUrl;
  final Map<String, dynamic> layout;

  const StoryTemplate({
    required this.id,
    required this.name,
    required this.description,
    required this.type,
    required this.category,
    required this.previewImageUrl,
    required this.layout,
  });

  factory StoryTemplate.fromJson(Map<String, dynamic> json) => StoryTemplate(
    id: json['id'],
    name: json['name'],
    description: json['description'],
    type: StoryType.values.byName(json['type']),
    category: json['category'],
    previewImageUrl: json['previewImageUrl'],
    layout: json['layout']?.cast<String, dynamic>() ?? {},
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'description': description,
    'type': type.name,
    'category': category,
    'previewImageUrl': previewImageUrl,
    'layout': layout,
  };
}
import 'package:narrativebio/models/user.dart';
import 'package:narrativebio/supabase/supabase_config.dart';

/// Service class for managing user data in Supabase
class UserService {
  /// Get current user profile from database
  static Future<User?> getCurrentUserProfile() async {
    final currentUser = SupabaseAuth.currentUser;
    if (currentUser == null) return null;

    try {
      final userData = await SupabaseService.selectSingle(
        'users',
        filters: {'id': currentUser.id},
      );

      if (userData != null) {
        return User.fromJson({
          'id': userData['id'],
          'name': userData['name'],
          'email': userData['email'],
          'subscriptionTier': userData['subscription_tier'],
          'joinDate': userData['join_date'],
        });
      }
    } catch (e) {
      throw 'Failed to fetch user profile: $e';
    }
    
    return null;
  }

  /// Update user profile
  static Future<User> updateUserProfile({
    required String userId,
    String? name,
    String? subscriptionTier,
  }) async {
    try {
      final updateData = <String, dynamic>{};
      if (name != null) updateData['name'] = name;
      if (subscriptionTier != null) updateData['subscription_tier'] = subscriptionTier;

      if (updateData.isEmpty) {
        throw 'No data to update';
      }

      final result = await SupabaseService.update(
        'users',
        updateData,
        filters: {'id': userId},
      );

      if (result.isNotEmpty) {
        final userData = result.first;
        return User.fromJson({
          'id': userData['id'],
          'name': userData['name'],
          'email': userData['email'],
          'subscriptionTier': userData['subscription_tier'],
          'joinDate': userData['join_date'],
        });
      } else {
        throw 'User not found';
      }
    } catch (e) {
      throw 'Failed to update user profile: $e';
    }
  }

  /// Get user by ID
  static Future<User?> getUserById(String userId) async {
    try {
      final userData = await SupabaseService.selectSingle(
        'users',
        filters: {'id': userId},
      );

      if (userData != null) {
        return User.fromJson({
          'id': userData['id'],
          'name': userData['name'],
          'email': userData['email'],
          'subscriptionTier': userData['subscription_tier'],
          'joinDate': userData['join_date'],
        });
      }
    } catch (e) {
      throw 'Failed to fetch user: $e';
    }
    
    return null;
  }

  /// Check if user has reached their monthly story limit
  static Future<bool> hasReachedStoryLimit(String userId) async {
    try {
      final user = await getUserById(userId);
      if (user == null) return true;

      // Get story count for current month
      final now = DateTime.now();
      final monthStart = DateTime(now.year, now.month, 1);
      
      final storyCount = await SupabaseService.select(
        'stories',
        filters: {'user_id': userId},
      );

      // Filter stories for current month
      final monthlyStories = storyCount.where((story) {
        final generatedAt = DateTime.parse(story['generated_at']);
        return generatedAt.isAfter(monthStart);
      }).length;

      // Check limits based on subscription tier
      switch (user.subscriptionTier) {
        case 'basic':
          return monthlyStories >= 3;
        case 'pro':
          return monthlyStories >= 10;
        case 'enterprise':
          return false; // Unlimited
        default:
          return monthlyStories >= 3;
      }
    } catch (e) {
      throw 'Failed to check story limit: $e';
    }
  }

  /// Get remaining stories for current month
  static Future<int> getRemainingStories(String userId) async {
    try {
      final user = await getUserById(userId);
      if (user == null) return 0;

      // Get story count for current month
      final now = DateTime.now();
      final monthStart = DateTime(now.year, now.month, 1);
      
      final storyCount = await SupabaseService.select(
        'stories',
        filters: {'user_id': userId},
      );

      // Filter stories for current month
      final monthlyStories = storyCount.where((story) {
        final generatedAt = DateTime.parse(story['generated_at']);
        return generatedAt.isAfter(monthStart);
      }).length;

      // Calculate remaining based on subscription tier
      switch (user.subscriptionTier) {
        case 'basic':
          return (3 - monthlyStories).clamp(0, 3);
        case 'pro':
          return (10 - monthlyStories).clamp(0, 10);
        case 'enterprise':
          return -1; // Unlimited
        default:
          return (3 - monthlyStories).clamp(0, 3);
      }
    } catch (e) {
      throw 'Failed to get remaining stories: $e';
    }
  }
}
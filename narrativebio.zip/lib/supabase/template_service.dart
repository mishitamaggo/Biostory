import 'package:narrativebio/models/story.dart';
import 'package:narrativebio/supabase/supabase_config.dart';

/// Service class for managing story templates in Supabase
class TemplateService {
  /// Get all active story templates
  static Future<List<StoryTemplate>> getActiveTemplates({
    StoryType? typeFilter,
    String? categoryFilter,
  }) async {
    try {
      final filters = <String, dynamic>{'is_active': true};
      if (typeFilter != null) {
        filters['type'] = typeFilter.name;
      }
      if (categoryFilter != null) {
        filters['category'] = categoryFilter;
      }

      final templatesData = await SupabaseService.select(
        'story_templates',
        filters: filters,
        orderBy: 'name',
        ascending: true,
      );

      return templatesData.map((data) => StoryTemplate.fromJson({
        'id': data['id'],
        'name': data['name'],
        'description': data['description'],
        'type': data['type'],
        'category': data['category'],
        'previewImageUrl': data['preview_image_url'],
        'layout': data['layout'],
      })).toList();
    } catch (e) {
      throw 'Failed to fetch templates: $e';
    }
  }

  /// Get a specific template by ID
  static Future<StoryTemplate?> getTemplateById(String templateId) async {
    try {
      final templateData = await SupabaseService.selectSingle(
        'story_templates',
        filters: {'id': templateId, 'is_active': true},
      );

      if (templateData != null) {
        return StoryTemplate.fromJson({
          'id': templateData['id'],
          'name': templateData['name'],
          'description': templateData['description'],
          'type': templateData['type'],
          'category': templateData['category'],
          'previewImageUrl': templateData['preview_image_url'],
          'layout': templateData['layout'],
        });
      }
    } catch (e) {
      throw 'Failed to fetch template: $e';
    }
    
    return null;
  }

  /// Get templates by type
  static Future<List<StoryTemplate>> getTemplatesByType(StoryType type) async {
    try {
      return await getActiveTemplates(typeFilter: type);
    } catch (e) {
      throw 'Failed to fetch templates by type: $e';
    }
  }

  /// Get templates by category
  static Future<List<StoryTemplate>> getTemplatesByCategory(String category) async {
    try {
      return await getActiveTemplates(categoryFilter: category);
    } catch (e) {
      throw 'Failed to fetch templates by category: $e';
    }
  }

  /// Get all unique categories
  static Future<List<String>> getCategories() async {
    try {
      final result = await SupabaseService.from('story_templates')
          .select('category')
          .eq('is_active', true)
          .order('category');

      final categories = result
          .map((data) => data['category'] as String)
          .toSet()
          .toList();

      return categories;
    } catch (e) {
      throw 'Failed to fetch categories: $e';
    }
  }

  /// Get featured templates (could be based on usage, ratings, etc.)
  static Future<List<StoryTemplate>> getFeaturedTemplates({int limit = 6}) async {
    try {
      // For now, just return the most recent active templates
      final templatesData = await SupabaseService.select(
        'story_templates',
        filters: {'is_active': true},
        orderBy: 'created_at',
        ascending: false,
        limit: limit,
      );

      return templatesData.map((data) => StoryTemplate.fromJson({
        'id': data['id'],
        'name': data['name'],
        'description': data['description'],
        'type': data['type'],
        'category': data['category'],
        'previewImageUrl': data['preview_image_url'],
        'layout': data['layout'],
      })).toList();
    } catch (e) {
      throw 'Failed to fetch featured templates: $e';
    }
  }

  /// Search templates by name or description
  static Future<List<StoryTemplate>> searchTemplates(String query) async {
    try {
      // Using direct query builder for text search
      final result = await SupabaseService.from('story_templates')
          .select()
          .eq('is_active', true)
          .or('name.ilike.%$query%,description.ilike.%$query%')
          .order('name');

      return result.map((data) => StoryTemplate.fromJson({
        'id': data['id'],
        'name': data['name'],
        'description': data['description'],
        'type': data['type'],
        'category': data['category'],
        'previewImageUrl': data['preview_image_url'],
        'layout': data['layout'],
      })).toList();
    } catch (e) {
      throw 'Failed to search templates: $e';
    }
  }

  /// Admin function: Create a new template (requires service role)
  static Future<StoryTemplate> createTemplate({
    required String name,
    required String description,
    required StoryType type,
    required String category,
    required String previewImageUrl,
    required Map<String, dynamic> layout,
  }) async {
    try {
      final now = DateTime.now();
      final templateData = {
        'name': name,
        'description': description,
        'type': type.name,
        'category': category,
        'preview_image_url': previewImageUrl,
        'layout': layout,
        'is_active': true,
        'created_at': now.toIso8601String(),
        'updated_at': now.toIso8601String(),
      };

      final result = await SupabaseService.insert('story_templates', templateData);
      
      if (result.isNotEmpty) {
        final data = result.first;
        return StoryTemplate.fromJson({
          'id': data['id'],
          'name': data['name'],
          'description': data['description'],
          'type': data['type'],
          'category': data['category'],
          'previewImageUrl': data['preview_image_url'],
          'layout': data['layout'],
        });
      } else {
        throw 'Failed to create template';
      }
    } catch (e) {
      throw 'Failed to create template: $e';
    }
  }

  /// Admin function: Update a template (requires service role)
  static Future<StoryTemplate> updateTemplate(
    String templateId, {
    String? name,
    String? description,
    String? category,
    String? previewImageUrl,
    Map<String, dynamic>? layout,
    bool? isActive,
  }) async {
    try {
      final updateData = <String, dynamic>{
        'updated_at': DateTime.now().toIso8601String(),
      };

      if (name != null) updateData['name'] = name;
      if (description != null) updateData['description'] = description;
      if (category != null) updateData['category'] = category;
      if (previewImageUrl != null) updateData['preview_image_url'] = previewImageUrl;
      if (layout != null) updateData['layout'] = layout;
      if (isActive != null) updateData['is_active'] = isActive;

      final result = await SupabaseService.update(
        'story_templates',
        updateData,
        filters: {'id': templateId},
      );

      if (result.isNotEmpty) {
        final data = result.first;
        return StoryTemplate.fromJson({
          'id': data['id'],
          'name': data['name'],
          'description': data['description'],
          'type': data['type'],
          'category': data['category'],
          'previewImageUrl': data['preview_image_url'],
          'layout': data['layout'],
        });
      } else {
        throw 'Template not found';
      }
    } catch (e) {
      throw 'Failed to update template: $e';
    }
  }

  /// Admin function: Deactivate a template (requires service role)
  static Future<void> deactivateTemplate(String templateId) async {
    try {
      await updateTemplate(templateId, isActive: false);
    } catch (e) {
      throw 'Failed to deactivate template: $e';
    }
  }
}
import 'package:narrativebio/models/story.dart';
import 'package:narrativebio/supabase/supabase_config.dart';

/// Service class for managing story data in Supabase
class StoryService {
  /// Get all stories for a specific project
  static Future<List<Story>> getStoriesForProject(String projectId) async {
    try {
      final storiesData = await SupabaseService.select(
        'stories',
        filters: {'project_id': projectId},
        orderBy: 'generated_at',
        ascending: false,
      );

      return storiesData.map((data) => Story.fromJson({
        'id': data['id'],
        'projectId': data['project_id'],
        'type': data['type'],
        'title': data['title'],
        'content': data['content'],
        'metadata': data['metadata'],
        'generatedAt': data['generated_at'],
      })).toList();
    } catch (e) {
      throw 'Failed to fetch stories: $e';
    }
  }

  /// Get all stories for the current user
  static Future<List<Story>> getUserStories({
    String? userId,
    StoryType? typeFilter,
    int? limit,
  }) async {
    final currentUser = SupabaseAuth.currentUser;
    final targetUserId = userId ?? currentUser?.id;
    
    if (targetUserId == null) {
      throw 'User not authenticated';
    }

    try {
      final filters = <String, dynamic>{'user_id': targetUserId};
      if (typeFilter != null) {
        filters['type'] = typeFilter.name;
      }

      final storiesData = await SupabaseService.select(
        'stories',
        filters: filters,
        orderBy: 'generated_at',
        ascending: false,
        limit: limit,
      );

      return storiesData.map((data) => Story.fromJson({
        'id': data['id'],
        'projectId': data['project_id'],
        'type': data['type'],
        'title': data['title'],
        'content': data['content'],
        'metadata': data['metadata'],
        'generatedAt': data['generated_at'],
      })).toList();
    } catch (e) {
      throw 'Failed to fetch user stories: $e';
    }
  }

  /// Get a specific story by ID
  static Future<Story?> getStoryById(String storyId) async {
    try {
      final storyData = await SupabaseService.selectSingle(
        'stories',
        filters: {'id': storyId},
      );

      if (storyData != null) {
        return Story.fromJson({
          'id': storyData['id'],
          'projectId': storyData['project_id'],
          'type': storyData['type'],
          'title': storyData['title'],
          'content': storyData['content'],
          'metadata': storyData['metadata'],
          'generatedAt': storyData['generated_at'],
        });
      }
    } catch (e) {
      throw 'Failed to fetch story: $e';
    }
    
    return null;
  }

  /// Create a new story
  static Future<Story> createStory({
    required String projectId,
    required StoryType type,
    required String title,
    required String content,
    Map<String, dynamic>? metadata,
  }) async {
    final currentUser = SupabaseAuth.currentUser;
    if (currentUser == null) {
      throw 'User not authenticated';
    }

    try {
      final now = DateTime.now();
      final storyData = {
        'project_id': projectId,
        'user_id': currentUser.id,
        'type': type.name,
        'title': title,
        'content': content,
        'metadata': metadata,
        'generated_at': now.toIso8601String(),
        'created_at': now.toIso8601String(),
        'updated_at': now.toIso8601String(),
      };

      final result = await SupabaseService.insert('stories', storyData);
      
      if (result.isNotEmpty) {
        final data = result.first;
        return Story.fromJson({
          'id': data['id'],
          'projectId': data['project_id'],
          'type': data['type'],
          'title': data['title'],
          'content': data['content'],
          'metadata': data['metadata'],
          'generatedAt': data['generated_at'],
        });
      } else {
        throw 'Failed to create story';
      }
    } catch (e) {
      throw 'Failed to create story: $e';
    }
  }

  /// Update an existing story
  static Future<Story> updateStory(
    String storyId, {
    String? title,
    String? content,
    Map<String, dynamic>? metadata,
  }) async {
    try {
      final updateData = <String, dynamic>{
        'updated_at': DateTime.now().toIso8601String(),
      };

      if (title != null) updateData['title'] = title;
      if (content != null) updateData['content'] = content;
      if (metadata != null) updateData['metadata'] = metadata;

      final result = await SupabaseService.update(
        'stories',
        updateData,
        filters: {'id': storyId},
      );

      if (result.isNotEmpty) {
        final data = result.first;
        return Story.fromJson({
          'id': data['id'],
          'projectId': data['project_id'],
          'type': data['type'],
          'title': data['title'],
          'content': data['content'],
          'metadata': data['metadata'],
          'generatedAt': data['generated_at'],
        });
      } else {
        throw 'Story not found';
      }
    } catch (e) {
      throw 'Failed to update story: $e';
    }
  }

  /// Delete a story
  static Future<void> deleteStory(String storyId) async {
    try {
      await SupabaseService.delete(
        'stories',
        filters: {'id': storyId},
      );
    } catch (e) {
      throw 'Failed to delete story: $e';
    }
  }

  /// Get stories count by type for the current user
  static Future<Map<StoryType, int>> getStoriesCountByType() async {
    final currentUser = SupabaseAuth.currentUser;
    if (currentUser == null) {
      throw 'User not authenticated';
    }

    try {
      final stories = await getUserStories();
      final countByType = <StoryType, int>{};
      
      for (final type in StoryType.values) {
        countByType[type] = stories.where((s) => s.type == type).length;
      }
      
      return countByType;
    } catch (e) {
      throw 'Failed to get stories count: $e';
    }
  }

  /// Get monthly story count for current user
  static Future<int> getMonthlyStoryCount() async {
    final currentUser = SupabaseAuth.currentUser;
    if (currentUser == null) {
      throw 'User not authenticated';
    }

    try {
      final now = DateTime.now();
      final monthStart = DateTime(now.year, now.month, 1);
      
      final stories = await getUserStories();
      
      return stories.where((story) {
        return story.generatedAt.isAfter(monthStart);
      }).length;
    } catch (e) {
      throw 'Failed to get monthly story count: $e';
    }
  }

  /// Get recent stories for dashboard
  static Future<List<Story>> getRecentStories({int limit = 5}) async {
    final currentUser = SupabaseAuth.currentUser;
    if (currentUser == null) {
      throw 'User not authenticated';
    }

    try {
      return await getUserStories(limit: limit);
    } catch (e) {
      throw 'Failed to get recent stories: $e';
    }
  }

  /// Search stories by title or content
  static Future<List<Story>> searchStories(String query) async {
    final currentUser = SupabaseAuth.currentUser;
    if (currentUser == null) {
      throw 'User not authenticated';
    }

    try {
      // Using direct query builder for text search
      final result = await SupabaseService.from('stories')
          .select()
          .eq('user_id', currentUser.id)
          .or('title.ilike.%$query%,content.ilike.%$query%')
          .order('generated_at', ascending: false);

      return result.map((data) => Story.fromJson({
        'id': data['id'],
        'projectId': data['project_id'],
        'type': data['type'],
        'title': data['title'],
        'content': data['content'],
        'metadata': data['metadata'],
        'generatedAt': data['generated_at'],
      })).toList();
    } catch (e) {
      throw 'Failed to search stories: $e';
    }
  }
}
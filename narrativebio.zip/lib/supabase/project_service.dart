import 'package:narrativebio/models/project.dart';
import 'package:narrativebio/supabase/supabase_config.dart';

/// Service class for managing project data in Supabase
class ProjectService {
  /// Get all projects for the current user
  static Future<List<Project>> getUserProjects({
    String? userId,
    ProjectStatus? statusFilter,
    int? limit,
  }) async {
    final currentUser = SupabaseAuth.currentUser;
    final targetUserId = userId ?? currentUser?.id;
    
    if (targetUserId == null) {
      throw 'User not authenticated';
    }

    try {
      final filters = <String, dynamic>{'user_id': targetUserId};
      if (statusFilter != null) {
        filters['status'] = statusFilter.name;
      }

      final projectsData = await SupabaseService.select(
        'projects',
        filters: filters,
        orderBy: 'updated_at',
        ascending: false,
        limit: limit,
      );

      return projectsData.map((data) => Project.fromJson({
        'id': data['id'],
        'title': data['title'],
        'description': data['description'],
        'status': data['status'],
        'researchContent': data['research_content'],
        'generatedStory': data['generated_story'],
        'selectedTemplate': data['selected_template'],
        'createdAt': data['created_at'],
        'updatedAt': data['updated_at'],
      })).toList();
    } catch (e) {
      throw 'Failed to fetch projects: $e';
    }
  }

  /// Get a specific project by ID
  static Future<Project?> getProjectById(String projectId) async {
    try {
      final projectData = await SupabaseService.selectSingle(
        'projects',
        filters: {'id': projectId},
      );

      if (projectData != null) {
        return Project.fromJson({
          'id': projectData['id'],
          'title': projectData['title'],
          'description': projectData['description'],
          'status': projectData['status'],
          'researchContent': projectData['research_content'],
          'generatedStory': projectData['generated_story'],
          'selectedTemplate': projectData['selected_template'],
          'createdAt': projectData['created_at'],
          'updatedAt': projectData['updated_at'],
        });
      }
    } catch (e) {
      throw 'Failed to fetch project: $e';
    }
    
    return null;
  }

  /// Create a new project
  static Future<Project> createProject({
    required String title,
    required String description,
    String? researchContent,
  }) async {
    final currentUser = SupabaseAuth.currentUser;
    if (currentUser == null) {
      throw 'User not authenticated';
    }

    try {
      final now = DateTime.now();
      final projectData = {
        'user_id': currentUser.id,
        'title': title,
        'description': description,
        'status': ProjectStatus.draft.name,
        'research_content': researchContent,
        'created_at': now.toIso8601String(),
        'updated_at': now.toIso8601String(),
      };

      final result = await SupabaseService.insert('projects', projectData);
      
      if (result.isNotEmpty) {
        final data = result.first;
        return Project.fromJson({
          'id': data['id'],
          'title': data['title'],
          'description': data['description'],
          'status': data['status'],
          'researchContent': data['research_content'],
          'generatedStory': data['generated_story'],
          'selectedTemplate': data['selected_template'],
          'createdAt': data['created_at'],
          'updatedAt': data['updated_at'],
        });
      } else {
        throw 'Failed to create project';
      }
    } catch (e) {
      throw 'Failed to create project: $e';
    }
  }

  /// Update an existing project
  static Future<Project> updateProject(
    String projectId,
    Project updatedProject,
  ) async {
    try {
      final updateData = {
        'title': updatedProject.title,
        'description': updatedProject.description,
        'status': updatedProject.status.name,
        'research_content': updatedProject.researchContent,
        'generated_story': updatedProject.generatedStory,
        'selected_template': updatedProject.selectedTemplate,
        'updated_at': DateTime.now().toIso8601String(),
      };

      final result = await SupabaseService.update(
        'projects',
        updateData,
        filters: {'id': projectId},
      );

      if (result.isNotEmpty) {
        final data = result.first;
        return Project.fromJson({
          'id': data['id'],
          'title': data['title'],
          'description': data['description'],
          'status': data['status'],
          'researchContent': data['research_content'],
          'generatedStory': data['generated_story'],
          'selectedTemplate': data['selected_template'],
          'createdAt': data['created_at'],
          'updatedAt': data['updated_at'],
        });
      } else {
        throw 'Project not found';
      }
    } catch (e) {
      throw 'Failed to update project: $e';
    }
  }

  /// Update project status
  static Future<Project> updateProjectStatus(
    String projectId,
    ProjectStatus status,
  ) async {
    try {
      final updateData = {
        'status': status.name,
        'updated_at': DateTime.now().toIso8601String(),
      };

      final result = await SupabaseService.update(
        'projects',
        updateData,
        filters: {'id': projectId},
      );

      if (result.isNotEmpty) {
        final data = result.first;
        return Project.fromJson({
          'id': data['id'],
          'title': data['title'],
          'description': data['description'],
          'status': data['status'],
          'researchContent': data['research_content'],
          'generatedStory': data['generated_story'],
          'selectedTemplate': data['selected_template'],
          'createdAt': data['created_at'],
          'updatedAt': data['updated_at'],
        });
      } else {
        throw 'Project not found';
      }
    } catch (e) {
      throw 'Failed to update project status: $e';
    }
  }

  /// Delete a project
  static Future<void> deleteProject(String projectId) async {
    try {
      await SupabaseService.delete(
        'projects',
        filters: {'id': projectId},
      );
    } catch (e) {
      throw 'Failed to delete project: $e';
    }
  }

  /// Get projects count by status for the current user
  static Future<Map<ProjectStatus, int>> getProjectsCountByStatus() async {
    final currentUser = SupabaseAuth.currentUser;
    if (currentUser == null) {
      throw 'User not authenticated';
    }

    try {
      final projects = await getUserProjects();
      final countByStatus = <ProjectStatus, int>{};
      
      for (final status in ProjectStatus.values) {
        countByStatus[status] = projects.where((p) => p.status == status).length;
      }
      
      return countByStatus;
    } catch (e) {
      throw 'Failed to get projects count: $e';
    }
  }

  /// Archive old completed projects (older than 6 months)
  static Future<int> archiveOldProjects() async {
    final currentUser = SupabaseAuth.currentUser;
    if (currentUser == null) {
      throw 'User not authenticated';
    }

    try {
      final sixMonthsAgo = DateTime.now().subtract(const Duration(days: 180));
      
      // Get old completed projects
      final oldProjects = await SupabaseService.select(
        'projects',
        filters: {
          'user_id': currentUser.id,
          'status': ProjectStatus.completed.name,
        },
      );

      final projectsToArchive = oldProjects.where((project) {
        final updatedAt = DateTime.parse(project['updated_at']);
        return updatedAt.isBefore(sixMonthsAgo);
      }).toList();

      // Update status to archived
      for (final project in projectsToArchive) {
        await updateProjectStatus(project['id'], ProjectStatus.archived);
      }

      return projectsToArchive.length;
    } catch (e) {
      throw 'Failed to archive old projects: $e';
    }
  }
}